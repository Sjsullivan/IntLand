package com.bushbot.com.bushbot.maven.eclipse;

import net.db.hibernate.*;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeoutException;

import discord4j.core.DiscordClient;
import discord4j.core.GatewayDiscordClient;
import discord4j.core.event.domain.interaction.ButtonInteractionEvent;
import discord4j.core.event.domain.lifecycle.ReadyEvent;
import discord4j.core.event.domain.message.MessageCreateEvent;
import discord4j.core.object.component.ActionRow;
import discord4j.core.object.component.Button;
import discord4j.core.object.entity.Message;
import discord4j.core.object.entity.User;
import discord4j.core.spec.MessageCreateSpec;
import reactor.core.publisher.Mono;

/**
 * Hello world, and all who inhabit it!
 * AH OW OOF OH DOW OH GAHA OOF
 *
 */
public class IntLand 
{
	private static final Logger sLogger = Logger.getLogger(UserService.class.getName());
	
    public static void main( String[] args )
    {
        DiscordClient client = DiscordClient.create("OTQ1ODQ0NTA4NjQ4NjY5MjE0.YhWEVw.c96pEOSQ8nBJ4az8PHOO-gyBubU");
        
        Mono<Void> login = client.withGateway((GatewayDiscordClient gateway) -> {
        	  // ReadyEvent example
        	Button button = Button.primary("custom-id", "Click me!!");
        	Button testButton = Button.success("testButton", "Click here!");
        	
        	
        	  Mono<Void> printOnLogin = gateway.on(ReadyEvent.class, event ->
        	      Mono.fromRunnable(() -> {
        	        final User self = event.getSelf();
        	        System.out.printf("Logged in as %s#%s%n", self.getUsername(), self.getDiscriminator());
        	      }))
        	      .then();
        	  
        	  // MessageCreateEvent example
        	  Mono<Void> handleBingBongCommand = gateway.on(MessageCreateEvent.class, event -> {
        	    Message message = event.getMessage();

        	    Button testButton2 = Button.success("testButton3", "Click here for free money!");
            	final Button testButton3 = testButton2.disabled();
        	    
        	    if (message.getContent().equalsIgnoreCase("!bingBong")) {
        	      return message.getChannel()
        	          .flatMap(channel -> channel.createMessage(
        	        		  MessageCreateSpec.builder()
        	        		  .content("Fuck ya life!")
        	        		  .addComponent(ActionRow.of(testButton))
        	        		  .addComponent(ActionRow.of(testButton3))
        	        		  .build()
        	        		  )
        	        		  );
        	    }

        	    return Mono.empty();
        	  }).then();
        	  
        	  Mono<Void> handleViewArmoryCommand = gateway.on(MessageCreateEvent.class, event -> {
          	    Message message = event.getMessage();
          	    List<Armory> userArmory;
          	    net.db.hibernate.User tempUser;
          	    int count;
          	    String msg = "";
          	    Button testButton2 = Button.success("testButton3", "Click here for free money!");
              	final Button testButton3 = testButton2.disabled();
          	    
          	    if (message.getContent().equalsIgnoreCase("!viewArmory")||message.getContent().startsWith("!va")) {
          	    	 try {
	            		  tempUser = UserService.getUserByDiscordId(event.getMessage().getUserData().id().asString());
	            		  userArmory = ArmoryService.getArmorysByUserId(tempUser.getId());
	            		 if(userArmory!=null)
	               	     {
	               	    	 if(userArmory.size()>20)
	               	    	 {
	               	    		 Armory arm;
	               	    		 for(int x=0;x<20;x++)
	               	    		 {
	               	    			 arm = userArmory.get(x);
	               	    			 msg +=""+arm.getId()+" lvl: "+arm.getLevel()+" name: "+WeaponService.getWeaponById(arm.getWeaponId()).getName()+" rarity: "+WeaponService.getWeaponById(arm.getWeaponId()).getRarity()+"\n";
	               	    		 }
	               	    	 }
	               	    	 else
	               	    	 {
	               	    		 for(Armory arm : userArmory)
	               	    		 {
	               	    			msg +=""+arm.getId()+" lvl: "+arm.getLevel()+" name: "+WeaponService.getWeaponById(arm.getWeaponId()).getName()+" rarity: "+WeaponService.getWeaponById(arm.getWeaponId()).getRarity()+"\n";
	               	    		 }
	               	    	 }
	               	    	 final String result = msg;
	               	    	return message.getChannel()
									.flatMap(channel -> channel.createMessage(result));
	               	     }
	               	     else
	               	     {
	               	    	return message.getChannel()
									.flatMap(channel -> channel.createMessage("You don't have any armories to display!"));
	               	     }
	            	  } catch (BusinessException e) {
	            		  sLogger.log(Level.WARNING, e.getMessage());
	            	  } 
          	    
          	    }

          	    return Mono.empty();
          	  }).then();

        	  Mono<Void> handleViewMemeCommand = gateway.on(MessageCreateEvent.class, event -> {
            	    Message message = event.getMessage();
            	    List<Meme> userMeme;
            	    net.db.hibernate.User tempUser;
            	    int count;
            	    String msg = "";
            	    Button testButton2 = Button.success("testButton3", "Click here for free money!");
                	final Button testButton3 = testButton2.disabled();
            	    
            	    if (message.getContent().equalsIgnoreCase("!viewMeme")||message.getContent().startsWith("!vm")) {
            	    	 try {
  	            		  tempUser = UserService.getUserByDiscordId(event.getMessage().getUserData().id().asString());
  	            		  userMeme = MemeService.getMemesByUserId(tempUser.getId());
  	            		 if(userMeme!=null)
  	               	     {
  	               	    	 if(userMeme.size()>20)
  	               	    	 {
  	               	    		 Meme mem;
  	               	    		 for(int x=0;x<20;x++)
  	               	    		 {
  	               	    			 mem = userMeme.get(x);
  	               	    			 msg +=""+mem.getId()+" lvl: "+mem.getLevel()+" name: "+MemeListService.getMemeListById(mem.getMemeListId()).getName()+" rarity: "+MemeListService.getMemeListById(mem.getMemeListId()).getRarity()+"\n";
  	               	    		 }
  	               	    	 }
  	               	    	 else
  	               	    	 {
  	               	    		 for(Meme mem : userMeme)
  	               	    		 {
  	               	    			msg +=""+mem.getId()+" lvl: "+mem.getLevel()+" name: "+MemeListService.getMemeListById(mem.getMemeListId()).getName()+" rarity: "+MemeListService.getMemeListById(mem.getMemeListId()).getRarity()+"\n";
  	               	    		 }
  	               	    	 }
  	               	    	 final String result = msg;
  	               	    	return message.getChannel()
  									.flatMap(channel -> channel.createMessage(result));
  	               	     }
  	               	     else
  	               	     {
  	               	    	return message.getChannel()
  									.flatMap(channel -> channel.createMessage("You don't have any memes to display!"));
  	               	     }
  	            	  } catch (BusinessException e) {
  	            		  sLogger.log(Level.WARNING, e.getMessage());
  	            	  } 
            	    
            	    }

            	    return Mono.empty();
            	  }).then();
        	  
        	  
        	  Mono<Void> handleCheckTheMudCommand = gateway.on(MessageCreateEvent.class, event -> {
          	    Message message = event.getMessage();
          	    Integer temp;
      	    	Integer value;
      	    	Integer minDiff;
      	    	Integer secDiff;
      	    	LocalDateTime localDate = LocalDateTime.now();
          	    
          	    if (message.getContent().equalsIgnoreCase("!checkTheMud")||message.getContent().equalsIgnoreCase("!ctm")) {
          	    	try {
        	    		//If user who posted message has an existing wallet
        	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
						if(tempWallet!=null)
							{
							//If user's flags allow them to farm again
							Flags tempFlags = FlagsService.getFlagsByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
							if( //Timer flag checking for at least 30 minutes after mudTimer
									(tempFlags.getMudTimer()==null||
									(localDate.isAfter(tempFlags.getMudTimer())&&
											(localDate.getMinute()-tempFlags.getMudTimer().getMinute()>=30 ||
											localDate.getHour()-tempFlags.getMudTimer().getHour()>=1 ||
											localDate.getDayOfMonth()-tempFlags.getMudTimer().getDayOfMonth()>=1 ||
											localDate.getMonth().getValue()-tempFlags.getMudTimer().getMonth().getValue()>=1 ||
											localDate.getYear()-tempFlags.getMudTimer().getYear()>=1)
									))
								)
							{
								//Then roll 
    							temp = ThreadLocalRandom.current().nextInt(0,1001);
    							//One mud piece 0-500, 3 mud pieces 501-900, 5 mud pieces 901-1000
    							value = temp < 500 ? 1 : (temp < 900 ? 3 : 5);
    							//Add the mud pieces to the user's wallet
    							WalletService.addMudPieces(value, tempWallet);
    							//And set mudTimer to reset timer
    							localDate = LocalDateTime.now();
    							tempFlags.setMudTimer(localDate);
    							//Update Flags
    							FlagsService.updateFlags(tempFlags);
    							
    							if(value==1) 
    							{
    								return message.getChannel()
        									.flatMap(channel -> channel.createMessage("The mud is still, you pull "+value+" piece as it begins to awaken!"));			
    							}
    							return message.getChannel()
    									.flatMap(channel -> channel.createMessage("The mud is still, you pull "+value+" pieces as it begins to awaken!"));
    							}
							minDiff = tempFlags.getMudTimer().getMinute()+30-localDate.getMinute();
							secDiff = 60 - localDate.getSecond();
								if(secDiff>0){
									return message.getChannel()
											.flatMap(channel -> channel.createMessage("The mud is bubbling, it should settle in "+(minDiff-1)+" min and "+secDiff+" sec."));
								}
								else
								{
									return message.getChannel()
											.flatMap(channel -> channel.createMessage("The mud is bubbling, it should settle in "+minDiff+" min."));
								}
							
							}
							
						else
						{
		            	    return message.getChannel()
		                	        .flatMap(channel -> channel.createMessage("The mud is bubbling... set up a wallet to investigate."));
						}
					} catch (BusinessException e) {
						sLogger.log(Level.WARNING, e.getMessage());
						System.out.println("Error retrieving wallet or user.");
					}
          	    }
          	    return Mono.empty();
          	  }).then();
        	  
        	  Mono<Void> handleMineCommand = gateway.on(MessageCreateEvent.class, event -> {
            	    Message message = event.getMessage();
            	    Integer temp;
        	    	Integer value;
        	    	Integer hourDiff;
        	    	Integer minDiff;
        	    	Integer secDiff;
        	    	
        	    	LocalDateTime localDate = LocalDateTime.now();
            	    
            	    if (message.getContent().equalsIgnoreCase("!mine")) {
            	    	try {
          	    		//If user who posted message has an existing wallet
          	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
  						if(tempWallet!=null)
  							{
  							//If user's flags allow them to mine again
  							Flags tempFlags = FlagsService.getFlagsByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
  							if( //Timer flag checking for at least 1 day after mineTimer
  									(tempFlags.getMineTimer()==null||
  									(localDate.isAfter(tempFlags.getMineTimer())&&
  											(localDate.getDayOfMonth()-tempFlags.getMineTimer().getDayOfMonth()>=1 ||
  											localDate.getMonth().getValue()-tempFlags.getMineTimer().getMonth().getValue()>=1 ||
  											localDate.getYear()-tempFlags.getMineTimer().getYear()>=1)
  									))
  								)
  							{
  								//Then roll 
      							temp = ThreadLocalRandom.current().nextInt(0,1001);
      							//One diamond 0-950, three diamonds 951-1000
      							value = temp < 950 ? 1 : 3;
      							//Add the diamond to the user's wallet
      							WalletService.addDarkDiamonds(value, tempWallet);
      							//And set mudTimer to reset timer
      							localDate = LocalDateTime.now();
      							tempFlags.setMineTimer(localDate);
      							//Update Flags
      							FlagsService.updateFlags(tempFlags);
      							if(value==1)
      							{
      								return message.getChannel()
          									.flatMap(channel -> channel.createMessage("The mine is open! You swing your pickaxe and grab "+value+" diamond, running as it collapses behind you!"));
      							}
      							return message.getChannel()
      									.flatMap(channel -> channel.createMessage("The mine is open! You swing your pickaxe and grab "+value+" diamonds, running as it collapses behind you"
      											+ "!"));
      							}
  							hourDiff = tempFlags.getMineTimer().getHour()+24-localDate.getHour();
  							minDiff = 60-localDate.getMinute();
  							secDiff = 60 - localDate.getSecond();
  								if(secDiff>0){
  									return message.getChannel()
  											.flatMap(channel -> channel.createMessage("The mine is collapsed, it should clear in "+(hourDiff-1)+" hrs, "+minDiff+" min, and "+secDiff+" sec."));
  								}
  								else
  								{
  									return message.getChannel()
  											.flatMap(channel -> channel.createMessage("The mine is collapsed, it should clear in "+(hourDiff-1)+" hrs, "+minDiff+" min."));
  								}
  							
  							}
  							
  						else
  						{
  		            	    return message.getChannel()
  		                	        .flatMap(channel -> channel.createMessage("The mine is eerily open... set up a wallet to investigate."));
  						}
  					} catch (BusinessException e) {
  						sLogger.log(Level.WARNING, e.getMessage());
  						System.out.println("Error retrieving wallet or user.");
  					}
            	    }
            	    return Mono.empty();
            	  }).then();
        	  
        	  Mono<Void> handleFarmCheckCommand = gateway.on(MessageCreateEvent.class, event -> {
            	    Message message = event.getMessage();
            	    Integer temp;
            	    Integer value;
            	    Integer minDiff;
            	    Integer secDiff;
            	    String minion;
            	    String extraMinion;
            	    Integer extraValue;
            	    String extraMessage = "";
            	    Boolean quickFarm = false;
            	    LocalDateTime localDate = LocalDateTime.now();
            	    
            	    if (message.getContent().equalsIgnoreCase("!farmCheck")||message.getContent().equalsIgnoreCase("!fc")) {
            	    	try {
            	    		//If user who posted message has an existing wallet
            	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
    						if(tempWallet!=null)
    							{
    							//If user's flags allow them to farm again
    							Flags tempFlags = FlagsService.getFlagsByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
    							if((tempFlags.getFarmCount()<tempFlags.getFarmCap())&&
    									//Timer flag checking for at least 5 minutes after farmTimer
    									(tempFlags.getFarmTimer() == null ||
    									(localDate.isAfter(tempFlags.getFarmTimer())&&
    											(localDate.getMinute()-tempFlags.getFarmTimer().getMinute()>=5 ||
    											localDate.getHour()-tempFlags.getFarmTimer().getHour()>=1 ||
    											localDate.getDayOfMonth()-tempFlags.getFarmTimer().getDayOfMonth()>=1 ||
    											localDate.getMonth().getValue()-tempFlags.getFarmTimer().getMonth().getValue()>=1 ||
    											localDate.getYear()-tempFlags.getFarmTimer().getYear()>=1)
    									))
    								)
    							{
    								//If user farmChecks within 5 minutes of it coming off cooldown
    								//Checking for edge cases of hour and day rolling over
    								if(tempFlags.getFarmTimer()!=null)
    								{
    									if(localDate.getMinute()-tempFlags.getFarmTimer().getMinute()<10 && localDate.getMinute()-tempFlags.getFarmTimer().getMinute()>0 ||
        										(localDate.getHour()-tempFlags.getFarmTimer().getHour()==1 && 60-localDate.getMinute()>50) ||
        										(localDate.getDayOfMonth()-tempFlags.getFarmTimer().getDayOfMonth()==1 && localDate.getHour()-tempFlags.getFarmTimer().getHour()==-23 && 60-localDate.getMinute()>50))
        								{
        									//Tier 1
                							temp = ThreadLocalRandom.current().nextInt(0,1001);
                							//Cannon 0-44 (90 coins), Melee 44-517 (21 coins), Caster 518-1000 (14 coins)
                							extraMinion = temp < 44 ? "Cannon" : (temp < 517 ? "Melee" : "Caster");
                							extraValue = temp < 44 ? 90 : (temp < 517 ? 21 : 14);
                							//Add the currency to the user's wallet
                							WalletService.addIntCoins(extraValue, tempWallet);
                							extraMessage = "The wave is positioned perfectly!\nYou farm an additional minion!\nKilled a "+extraMinion+" minion, you got "+extraValue+" coins! :coin:\n";
                							quickFarm = true;
        								}
    								}
    									
    								
    								
    								String extraMessagePrint = extraMessage;
    								//Then roll based on their tier. (TBI)
        							//Tier 1
        							temp = ThreadLocalRandom.current().nextInt(0,1001);
        							//Cannon 0-44 (90 coins), Melee 44-517 (21 coins), Caster 518-1000 (14 coins)
        							minion = temp < 44 ? "Cannon" : (temp < 517 ? "Melee" : "Caster");
        							value = temp < 44 ? 90 : (temp < 517 ? 21 : 14);
        							//Add the currency to the user's wallet
        							WalletService.addIntCoins(value, tempWallet);
        							//Then increment farmCount flag
        							//tempFlags.setFarmCount(tempFlags.getFarmCount()+1); -- Currently does not decrement elsewhere, hence the comment
        							//And set farmTimer to reset timer
        							localDate = LocalDateTime.now();
        							tempFlags.setFarmTimer(localDate);
        							//Update Flags
        							FlagsService.updateFlags(tempFlags);
        							return message.getChannel()
        									.flatMap(channel -> channel.createMessage(extraMessagePrint+"Killed a "+minion+" minion, you got "+value+" coins! :coin:"));
        							}
    							minDiff = tempFlags.getFarmTimer().getMinute()+5-localDate.getMinute();
    							secDiff = 60 - localDate.getSecond();
    								if(secDiff>0){
    									return message.getChannel()
    											.flatMap(channel -> channel.createMessage("You've been zoned, you can farm again in "+(minDiff-1)+" min and "+secDiff+" sec!"));
    								}
    								else
    								{
    									return message.getChannel()
    											.flatMap(channel -> channel.createMessage("You've been zoned, you can farm again in "+minDiff+" min!"));
    								}
    							
    							}
    							
    						else
    						{
    		            	    return message.getChannel()
    		                	        .flatMap(channel -> channel.createMessage("CS is important, set up a wallet to start farming!"));
    						}
    					} catch (BusinessException e) {
    						sLogger.log(Level.WARNING, e.getMessage());
    						System.out.println("Error retrieving wallet or user.");
    					}
            	    }
            	    return Mono.empty();
            	  }).then();
        	  
        	  Mono<Void> handleRecycleCommand = gateway.on(MessageCreateEvent.class, event -> {
          	    Message message = event.getMessage();
          	    Integer temp;
          	    Integer value;
          	    Integer minDiff;
          	    Integer secDiff;
          	    String type;
          	    String msg = "";
          	    LocalDateTime localDate = LocalDateTime.now();
          	    
          	    if (message.getContent().equalsIgnoreCase("!recycle")||message.getContent().startsWith("!rc")) {
          	    	try {
          	    		//If user who posted message has an existing wallet
          	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
  						if(tempWallet!=null)
  							{  
  							message.getChannel()
    	          	          .flatMap(channel -> channel.createMessage("https://images.neopets.com/images/noshomatic.gif").then());
  							//If user's wallet has valid currency
  							if(tempWallet.getMudPieces()>0)
  							{
  								int count = 0;
  								String line = message.getContent();
  								if(!line.equals("!rc"))
  								{
  									Pattern pattern = Pattern.compile("!rc\\s+\\d*");
  	  								Matcher matcher = pattern.matcher(line);
  	  								matcher.find();
  	  								line = matcher.group();
  	  							String[] strArr = new String[2];
  								strArr = line.split("\\s");
  								if(strArr[1]=="")
  								{
  									msg+="Putting a piece of mud in the machine, you stand back and watch.\n";
  									count = 1;
  								}

  								else if(tempWallet.getMudPieces()>=Integer.parseInt(strArr[1]) && Integer.parseInt(strArr[1])>0){count = Integer.parseInt(strArr[1]);}
  								else 
  								{
  									msg+="Hmm, that doesn't seem to be a valid number. The recycler will run once.\n";
  									count = 1;
  								}
  								
  								}
  								else 
  								{
  									msg+="Putting a piece of mud in the machine, you stand back and watch.\n";
  									count = 1;
  								}
  								for(int x=0;x<count;x++)
  								{
  								//Take one mud piece for the roll
  	  								WalletService.removeMudPieces(1,tempWallet);
  	  								//Then roll based on their tier. (TBI)
  	      							//Tier 1
  	      							temp = ThreadLocalRandom.current().nextInt(0,1001);
  	      							
  	      							//Roll for type of reward
  	      							//Gold 0-850, Diamond 851-950, Mud Artifact 951-1000
  	      							type = temp < 850 ? "Gold" : (temp < 950 ? "Diamond" : "MudArtifact");
  	      							switch(type) {
  	      							
  	      							case "Gold":
  	      								//If gold type rolled
  	      								//Gold 0-600 1, 601-900 5, 901-1000 10
  	      								value = temp < 600 ? 1 : (temp < 900 ? 5 : 10);
  	      								//Add the currency to the user's wallet
  	      								WalletService.addGlizzyGold(value, tempWallet);
  	      								msg += "The recycler whirrs, and spits out "+value+" bars of Glizzy Gold! <:Gold:943558944545181736>\n";
  	      								break;
  	      								
  	      							case "Diamond":
  	      								//If diamond type rolled
  	      								//Diamond 0-600 1, 601-900 3, 901-1000 5
  	      								value = temp < 600 ? 1 : (temp < 900 ? 3 : 5);
  	      								//Add the currency to the user's wallet
  	      								WalletService.addDarkDiamonds(value, tempWallet);
  	      								msg += "The recycler whirrs, and spits out "+value+" Dark Diamonds! :gem:\n";
  	      								break;
  	      								
  	      							case "MudArtifact":
  	      								//If Mud Artifact type rolled
  	      								WalletService.addMudArtifacts(1, tempWallet);
  	      								msg += "The recycler whirrs, and spits out... a strange artifact? <:outDaMud:943658842972123176> Hmm... \n";
  	      								break;	
  	      							
  	      							
  	      							default:
  	      								msg += "How are you seeing this? Please contact The Hairy One... immediately.\n";
  	      								break;
  	      							}
  								}
  								
      							final String result = msg;
      							return message.getChannel()
											.flatMap(channel -> channel.createMessage(result));
      							}
  								//Else display this message if they don't have valid currency
  									return message.getChannel()
  											.flatMap(channel -> channel.createMessage("You don't seem to have anything to recycle right now. Come back with some mud pieces!"));
  							
  							}
  						else
  						{
  		            	    return message.getChannel()
  		                	        .flatMap(channel -> channel.createMessage("The recycler stands tall, ready to check through mud for anything of interest hidden inside. Set up a wallet to interact!"));
  						}
  					} catch (BusinessException e) {
  						sLogger.log(Level.WARNING, e.getMessage());
  						System.out.println("Error retrieving wallet or user.");
  					}
          	    }
          	    return Mono.empty();
          	  }).then();
        	  
        	  Mono<Void> handleWeaponMachineCommand = gateway.on(MessageCreateEvent.class, event -> {
            	    Message message = event.getMessage();
            	    Integer temp;
            	    Integer value;
            	    Integer minDiff;
            	    Integer secDiff;
            	    String type;
            	    String msg = "";
            	    List<Weapon> availRewards;
            	    Weapon rewardWeapon;
            	    LocalDateTime localDate = LocalDateTime.now();
            	    
            	    if (message.getContent().equalsIgnoreCase("!weaponMachine")||message.getContent().startsWith("!wm")) {
            	    	try {
            	    		//If user who posted message has an existing wallet
            	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
    						if(tempWallet!=null)
    							{  
    							//If user's wallet has valid currency
    							if(tempWallet.getIntCoins()>=100)
    							{
    								int count = 1;
    								String line = message.getContent();
    								if(!line.equals("!wm"))
    								{
    									Pattern pattern = Pattern.compile("!wm\\s+\\d*");
    	  								Matcher matcher = pattern.matcher(line);
    	  								matcher.find();
    	  								line = matcher.group();
    	  							String[] strArr = new String[2];
    								strArr = line.split("\\s");
    								if(strArr[1]=="")
    								{
    									msg+="Putting your coins in the machine, you hear a rumbling noise.\n";
    									count = 1;
    								}
    							//DEBUG: System.out.println(Integer.parseInt(strArr[1]));
    								else if(tempWallet.getIntCoins()>=Integer.parseInt(strArr[1])*100 && Integer.parseInt(strArr[1])<=15 &&Integer.parseInt(strArr[1])>0){count = Integer.parseInt(strArr[1]);}
    								else 
    								{
    									msg+="Hmm, that doesn't seem to be a valid number (the machine can run up to 15 times at once). The weapon machine will dispense once.\n";
    									count = 1;
    								}
    								
    								}
    								else 
    								{
    									msg+="Putting your coins in the machine, you hear a rumbling noise.\n";
    									count = 1;
    								}
    								for(int x=0;x<count;x++)
    								{
    								//Take 100 IntCoins for the roll
    	  								WalletService.removeIntCoins(100,tempWallet);
    	  								//Then roll based on their tier. (TBI)
    	      							//Tier 1
    	      							temp = ThreadLocalRandom.current().nextInt(0,1001);
    	      							
    	      							//Roll for rarity of weapon
    	      							//Common 0-600, Rare 601-850, Epic 851-950, Legendary 951-997, Exotic 998-1000
    	      							type = temp < 600 ? "common" : (temp < 850 ? "rare" : (temp < 950 ? "epic" : temp < 997 ? "legendary" : "exotic"));
    	      							switch(type) {
    	      							
    	      							case "common":
    	      								//If common weapon rolled
    	      								availRewards = WeaponService.getWeaponsByRarity(type);
    	      								rewardWeapon = availRewards.get(new Random().nextInt(availRewards.size()));
    	      								ArmoryService.registerArmory(tempWallet.getUserId(),rewardWeapon.getId());
    	      								msg += "A "+type+" weapon falls from the machine -- "+rewardWeapon.getName()+"!\n";
    	      								break;
    	      								
    	      							case "rare":
    	      							//If rare weapon rolled
    	      								availRewards = WeaponService.getWeaponsByRarity(type);
    	      								rewardWeapon = availRewards.get(new Random().nextInt(availRewards.size()));
    	      								ArmoryService.registerArmory(tempWallet.getUserId(),rewardWeapon.getId());
    	      								msg += "A "+type+" weapon falls from the machine -- "+rewardWeapon.getName()+"!\n";
    	      								break;
    	      								
    	      							case "epic":
    	      							//If epic weapon rolled
    	      								availRewards = WeaponService.getWeaponsByRarity(type);
    	      								rewardWeapon = availRewards.get(new Random().nextInt(availRewards.size()));
    	      								ArmoryService.registerArmory(tempWallet.getUserId(),rewardWeapon.getId());
    	      								msg += "A "+type+" weapon falls from the machine -- "+rewardWeapon.getName()+"!\n";
    	      								break;
    	      							
    	      							case "legendary":
        	      						//If legendary weapon rolled
        	      							availRewards = WeaponService.getWeaponsByRarity(type);
        	      							rewardWeapon = availRewards.get(new Random().nextInt(availRewards.size()));
        	      							ArmoryService.registerArmory(tempWallet.getUserId(),rewardWeapon.getId());
        	      							msg += "A "+type+" weapon falls from the machine -- "+rewardWeapon.getName()+"!\n";
        	      							break;
        	      								
    	      							case "exotic":
        	      						//If exotic weapon rolled
        	      							availRewards = WeaponService.getWeaponsByRarity(type);
        	      							rewardWeapon = availRewards.get(new Random().nextInt(availRewards.size()));
        	      							ArmoryService.registerArmory(tempWallet.getUserId(),rewardWeapon.getId());
        	      							msg += "INCREDIBLE!!!\nA "+type+" weapon falls from the machine -- "+rewardWeapon.getName()+"!\n";
        	      							break;
    	      							
    	      							default:
    	      								msg += "How are you seeing this? Please contact The Hairy One... immediately.\n";
    	      								break;
    	      							}
    								}
    								
        							final String result = msg;
        							return message.getChannel()
  											.flatMap(channel -> channel.createMessage(result));
        							}
    								//Else display this message if they don't have valid currency
    									return message.getChannel()
    											.flatMap(channel -> channel.createMessage("You don't seem to have enough coins to pay right now. Come back with 100 IntCoins!"));
    							
    							}
    						else
    						{
    		            	    return message.getChannel()
    		                	        .flatMap(channel -> channel.createMessage("The weapon machine looms, and you sense the power contained within. Set up a wallet to interact!"));
    						}
    					} catch (BusinessException e) {
    						sLogger.log(Level.WARNING, e.getMessage());
    						System.out.println("Error retrieving wallet or user.");
    					}
            	    }
            	    return Mono.empty();
            	  }).then();
        	  
        	  Mono<Void> handleMemeMachineCommand = gateway.on(MessageCreateEvent.class, event -> {
          	    Message message = event.getMessage();
          	    Integer temp;
          	    Integer value;
          	    Integer minDiff;
          	    Integer secDiff;
          	    String type;
          	    String msg = "";
          	    List<MemeList> availRewards;
          	    MemeList rewardMemeList;
          	    LocalDateTime localDate = LocalDateTime.now();
          	    
          	    if (message.getContent().equalsIgnoreCase("!memeMachine")||message.getContent().startsWith("!mm")) {
          	    	try {
          	    		//If user who posted message has an existing wallet
          	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
  						if(tempWallet!=null)
  							{  
  							//If user's wallet has valid currency
  							if(tempWallet.getGlizzyGold()>=5)
  							{
  								int count = 1;
  								String line = message.getContent();
  								if(!line.equals("!mm"))
  								{
  									Pattern pattern = Pattern.compile("!mm\\s+\\d*");
  	  								Matcher matcher = pattern.matcher(line);
  	  								matcher.find();
  	  								line = matcher.group();
  	  							String[] strArr = new String[2];
  								strArr = line.split("\\s");
  								if(strArr[1]=="")
  								{
  									msg+="Putting your gold in the machine, you hear a rumbling noise.\n";
  									count = 1;
  								}
  							//DEBUG: System.out.println(Integer.parseInt(strArr[1]));
  								else if(tempWallet.getGlizzyGold()>=Integer.parseInt(strArr[1])*5 && Integer.parseInt(strArr[1])<=15 &&Integer.parseInt(strArr[1])>0){count = Integer.parseInt(strArr[1]);}
  								else 
  								{
  									msg+="Hmm, that doesn't seem to be a valid number (the machine can run up to 15 times at once). The meme machine will dispense once.\n";
  									count = 1;
  								}
  								
  								}
  								else 
  								{
  									msg+="Putting your gold in the machine, you hear a rumbling noise.\n";
  									count = 1;
  								}
  								for(int x=0;x<count;x++)
  								{
  								//Take 5 Glizzy Gold for the roll
  	  								WalletService.removeGlizzyGold(5,tempWallet);
  	  								//Then roll based on their tier. (TBI)
  	      							//Tier 1
  	      							temp = ThreadLocalRandom.current().nextInt(0,1001);
  	      							
  	      							//Roll for rarity of memeList
  	      							//Common 0-600, Rare 601-850, Epic 851-950, Legendary 951-997, Exotic 998-1000
  	      							type = temp < 600 ? "common" : (temp < 850 ? "rare" : (temp < 950 ? "epic" : temp < 997 ? "legendary" : "exotic"));
  	      							switch(type) {
  	      							
  	      							case "common":
  	      								//If common memeList rolled
  	      								availRewards = MemeListService.getMemeListsByRarity(type);
  	      								rewardMemeList = availRewards.get(new Random().nextInt(availRewards.size()));
  	      								MemeService.registerMeme(tempWallet.getUserId(),rewardMemeList.getId());
  	      								msg += "A "+type+" meme falls from the machine -- "+rewardMemeList.getName()+"!\n";
  	      								break;
  	      								
  	      							case "rare":
  	      							//If rare memeList rolled
  	      								availRewards = MemeListService.getMemeListsByRarity(type);
  	      								rewardMemeList = availRewards.get(new Random().nextInt(availRewards.size()));
  	      								MemeService.registerMeme(tempWallet.getUserId(),rewardMemeList.getId());
  	      								msg += "A "+type+" meme falls from the machine -- "+rewardMemeList.getName()+"!\n";
  	      								break;
  	      								
  	      							case "epic":
  	      							//If epic memeList rolled
  	      								availRewards = MemeListService.getMemeListsByRarity(type);
  	      								rewardMemeList = availRewards.get(new Random().nextInt(availRewards.size()));
  	      								MemeService.registerMeme(tempWallet.getUserId(),rewardMemeList.getId());
  	      								msg += "A "+type+" meme falls from the machine -- "+rewardMemeList.getName()+"!\n";
  	      								break;
  	      							
  	      							case "legendary":
      	      						//If legendary memeList rolled
      	      							availRewards = MemeListService.getMemeListsByRarity(type);
      	      							rewardMemeList = availRewards.get(new Random().nextInt(availRewards.size()));
      	      							MemeService.registerMeme(tempWallet.getUserId(),rewardMemeList.getId());
      	      							msg += "A "+type+" meme falls from the machine -- "+rewardMemeList.getName()+"!\n";
      	      							break;
      	      								
  	      							case "exotic":
      	      						//If exotic memeList rolled
      	      							availRewards = MemeListService.getMemeListsByRarity(type);
      	      							rewardMemeList = availRewards.get(new Random().nextInt(availRewards.size()));
      	      							MemeService.registerMeme(tempWallet.getUserId(),rewardMemeList.getId());
      	      							msg += "INCREDIBLE!!!\nA "+type+" meme falls from the machine -- "+rewardMemeList.getName()+"!\n";
      	      							break;
  	      							
  	      							default:
  	      								msg += "How are you seeing this? Please contact The Hairy One... immediately.\n";
  	      								break;
  	      							}
  								}
  								
      							final String result = msg;
      							return message.getChannel()
											.flatMap(channel -> channel.createMessage(result));
      							}
  								//Else display this message if they don't have valid currency
  									return message.getChannel()
  											.flatMap(channel -> channel.createMessage("You don't seem to have enough gold to pay right now. Come back with 5 Glizzy Gold!"));
  							
  							}
  						else
  						{
  		            	    return message.getChannel()
  		                	        .flatMap(channel -> channel.createMessage("The Meme machine looms, and you sense the power contained within. Set up a wallet to interact!"));
  						}
  					} catch (BusinessException e) {
  						sLogger.log(Level.WARNING, e.getMessage());
  						System.out.println("Error retrieving wallet or user.");
  					}
          	    }
          	    return Mono.empty();
          	  }).then();
        	  
        	  Mono<Void> handleArmoryDeleteCommand = gateway.on(MessageCreateEvent.class, event -> {
          	    Message message = event.getMessage();
          	    String temp;
          	    Integer value;
          	    String type;
          	    String msg = "";
          	    List<Weapon> availRewards;
          	    Weapon rewardWeapon;
          	    Armory tempArm;
          	    ArmoryDao armoryDao;
          	    LocalDateTime localDate = LocalDateTime.now();
          	    
          	    if (message.getContent().equalsIgnoreCase("!armoryDelete")||message.getContent().startsWith("!ad")) {
          	    	try {
          	    		//If user who posted message has an existing wallet
          	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
  						if(tempWallet!=null)
  							{  
  								String line = message.getContent();
  								if(!line.equals("!ad"))
  								{
  									Pattern pattern = Pattern.compile("!ad(\\s+\\d*)*");
  	  								Matcher matcher = pattern.matcher(line);
  	  								matcher.find();
  	  								line = matcher.group();
  	  							String[] strArr = new String[15];
  								strArr = line.split("\\s");
  							//DEBUG: System.out.println(Integer.parseInt(strArr[1]));
  								for(int x=1;x<strArr.length;x++)
  								{
  									if(strArr[x]!="")
  									{
  										tempArm = ArmoryService.getArmoryById(Integer.parseInt(strArr[x]));
  										//if Armory exists and is owned by the command runner
  										if(tempArm!=null && tempArm.getUserId() == tempWallet.getUserId())
  										{
  										//Check for rarity of weapon
  		  	      							type = WeaponService.getWeaponById(tempArm.getWeaponId()).getRarity();
  		  	      							temp = WeaponService.getWeaponById(tempArm.getWeaponId()).getName();
  		  	      							switch(type) {
  		  	      							
  		  	      							case "common":
  		  	      								//If common weapon smelted
  		  	      								armoryDao = new ArmoryDaoImpl();
  		  	      								try
  		  	      								{
  		  	      									armoryDao.deleteArmory(tempArm.getId());
  		  	      									WalletService.addWeaponCores(1,tempWallet);
  		  	      									msg += "You smelt a "+type+" weapon, "+temp+", and get 1 weapon core!\n";
  		  	      								} catch (Exception e) {
  		  	      									sLogger.log(Level.WARNING, e.getMessage());
  		  	      									System.out.println("Error retrieving armory.");
  		  	      								}
  		  	      								
  		  	      								break;
  		  	      								
  		  	      							case "rare":
  		  	      								//If rare weapon smelted
  		  	      								armoryDao = new ArmoryDaoImpl();
  		  	      								try
  		  	      								{
  		  	      									armoryDao.deleteArmory(tempArm.getId());
  		  	      									WalletService.addWeaponCores(2,tempWallet);
  		  	      									msg += "You smelt a "+type+" weapon, "+temp+", and get 2 weapon cores!\n";
  		  	      								} catch (Exception e) {
  		  	      									sLogger.log(Level.WARNING, e.getMessage());
  		  	      									System.out.println("Error retrieving armory.");
  		  	      								}
  		  	      								break;
  		  	      								
  		  	      							case "epic":
  		  	      								//If epic weapon smelted
  		  	      								armoryDao = new ArmoryDaoImpl();
  		  	      								try
  		  	      								{
  		  	      									armoryDao.deleteArmory(tempArm.getId());
  		  	      									WalletService.addWeaponCores(3,tempWallet);
  		  	      									msg += "You smelt a "+type+" weapon, "+temp+", and get 3 weapon cores!\n";
  		  	      								} catch (Exception e) {
  		  	      									sLogger.log(Level.WARNING, e.getMessage());
  		  	      									System.out.println("Error retrieving armory.");
  		  	      								}
  		  	      								break;
  		  	      							
  		  	      							case "legendary":
  		  	      								//If legendary weapon smelted
  		  	      								armoryDao = new ArmoryDaoImpl();
  		  	      								try
  		  	      								{
  		  	      									armoryDao.deleteArmory(tempArm.getId());
  		  	      									WalletService.addWeaponCores(4,tempWallet);
  		  	      									msg += "You smelt a "+type+" weapon, "+temp+", and get 4 weapon cores!\n";
  		  	      								} catch (Exception e) {
  		  	      									sLogger.log(Level.WARNING, e.getMessage());
  		  	      									System.out.println("Error retrieving armory.");
  		  	      								}
  		      	      							break;
  		      	      								
  		  	      							case "exotic":
  		  	      								//If exotic weapon smelted
  		  	      								armoryDao = new ArmoryDaoImpl();
  		  	      								try
  		  	      								{
  		  	      									armoryDao.deleteArmory(tempArm.getId());
  		  	      									WalletService.addWeaponCores(5,tempWallet);
  		  	      									msg += "You smelt a "+type+" weapon, "+temp+", and get 5 weapon cores!\n";
  		  	      								} catch (Exception e) {
  		  	      									sLogger.log(Level.WARNING, e.getMessage());
  		  	      									System.out.println("Error retrieving armory.");
  		  	      								}
  		      	      							break;
  		  	      							
  		  	      							default:
  		  	      								msg += "How are you seeing this? Please contact The Hairy One... immediately.\n";
  		  	      								break;
  		  	      							}
  		  								
  										}
  									}
  								}
  	      							
  								
      							final String result = msg;
      							return message.getChannel()
											.flatMap(channel -> channel.createMessage(result));
  								}
  						  	  }
  							} catch (BusinessException e) {
  						sLogger.log(Level.WARNING, e.getMessage());
  						System.out.println("Error retrieving wallet or user.");
  					}
          	    }
          	    return Mono.empty();
          	    }).then();
        	  
        	  Mono<Void> handleMemeDeleteCommand = gateway.on(MessageCreateEvent.class, event -> {
            	    Message message = event.getMessage();
            	    String temp;
            	    Integer value;
            	    String type;
            	    String msg = "";
            	    List<Weapon> availRewards;
            	    Weapon rewardWeapon;
            	    Meme tempMeme;
            	    MemeDao memeDao;
            	    LocalDateTime localDate = LocalDateTime.now();
            	    
            	    if (message.getContent().equalsIgnoreCase("!memeDelete")||message.getContent().startsWith("!md")) {
            	    	try {
            	    		//If user who posted message has an existing wallet
            	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
    						if(tempWallet!=null)
    							{  
    								String line = message.getContent();
    								if(!line.equals("!md"))
    								{
    									Pattern pattern = Pattern.compile("!md(\\s+\\d*)*");
    	  								Matcher matcher = pattern.matcher(line);
    	  								matcher.find();
    	  								line = matcher.group();
    	  							String[] strArr = new String[15];
    								strArr = line.split("\\s");
    							//DEBUG: System.out.println(Integer.parseInt(strArr[1]));
    								for(int x=1;x<strArr.length;x++)
    								{
    									if(strArr[x]!="")
    									{
    										tempMeme = MemeService.getMemeById(Integer.parseInt(strArr[x]));
    										//if Meme exists and is owned by the command runner
    										if(tempMeme!=null && tempMeme.getUserId() == tempWallet.getUserId())
    										{
    										//Check for rarity of weapon
    		  	      							type = MemeListService.getMemeListById(tempMeme.getMemeListId()).getRarity();
    		  	      							temp = MemeListService.getMemeListById(tempMeme.getMemeListId()).getName();
    		  	      							switch(type) {
    		  	      							
    		  	      							case "common":
    		  	      								//If common meme smelted
    		  	      								memeDao = new MemeDaoImpl();
    		  	      								try
    		  	      								{
    		  	      									memeDao.deleteMeme(tempMeme.getId());
    		  	      									WalletService.addMemeDust(1,tempWallet);
    		  	      									msg += "You smelt a "+type+" meme, "+temp+", and get 1 meme dust!\n";
    		  	      								} catch (Exception e) {
    		  	      									sLogger.log(Level.WARNING, e.getMessage());
    		  	      									System.out.println("Error retrieving meme.");
    		  	      								}
    		  	      								
    		  	      								break;
    		  	      								
    		  	      							case "rare":
    		  	      								//If rare meme smelted
    		  	      								memeDao = new MemeDaoImpl();
    		  	      								try
    		  	      								{
    		  	      									memeDao.deleteMeme(tempMeme.getId());
    		  	      									WalletService.addMemeDust(2,tempWallet);
    		  	      									msg += "You smelt a "+type+" meme, "+temp+", and get 2 meme dust!\n";
    		  	      								} catch (Exception e) {
    		  	      									sLogger.log(Level.WARNING, e.getMessage());
    		  	      									System.out.println("Error retrieving meme.");
    		  	      								}
    		  	      								break;
    		  	      								
    		  	      							case "epic":
    		  	      								//If epic meme smelted
    		  	      								memeDao = new MemeDaoImpl();
    		  	      								try
    		  	      								{
    		  	      									memeDao.deleteMeme(tempMeme.getId());
    		  	      									WalletService.addMemeDust(3,tempWallet);
    		  	      									msg += "You smelt a "+type+" meme, "+temp+", and get 3 meme dust!\n";
    		  	      								} catch (Exception e) {
    		  	      									sLogger.log(Level.WARNING, e.getMessage());
    		  	      									System.out.println("Error retrieving meme.");
    		  	      								}
    		  	      								break;
    		  	      							
    		  	      							case "legendary":
    		  	      								//If legendary meme smelted
    		  	      								memeDao = new MemeDaoImpl();
    		  	      								try
    		  	      								{
    		  	      									memeDao.deleteMeme(tempMeme.getId());
    		  	      									WalletService.addMemeDust(4,tempWallet);
    		  	      									msg += "You smelt a "+type+" meme, "+temp+", and get 4 meme dust!\n";
    		  	      								} catch (Exception e) {
    		  	      									sLogger.log(Level.WARNING, e.getMessage());
    		  	      									System.out.println("Error retrieving meme.");
    		  	      								}
    		      	      							break;
    		      	      								
    		  	      							case "exotic":
    		  	      								//If exotic meme smelted
    		  	      								memeDao = new MemeDaoImpl();
    		  	      								try
    		  	      								{
    		  	      									memeDao.deleteMeme(tempMeme.getId());
    		  	      									WalletService.addMemeDust(5,tempWallet);
    		  	      									msg += "You smelt a "+type+" meme, "+temp+", and get 5 meme dust!\n";
    		  	      								} catch (Exception e) {
    		  	      									sLogger.log(Level.WARNING, e.getMessage());
    		  	      									System.out.println("Error retrieving meme.");
    		  	      								}
    		      	      							break;
    		  	      							
    		  	      							default:
    		  	      								msg += "How are you seeing this? Please contact The Hairy One... immediately.\n";
    		  	      								break;
    		  	      							}
    		  								
    										}
    									}
    								}
    	      							
    								
        							final String result = msg;
        							return message.getChannel()
  											.flatMap(channel -> channel.createMessage(result));
    								}
    						  	  }
    							} catch (BusinessException e) {
    						sLogger.log(Level.WARNING, e.getMessage());
    						System.out.println("Error retrieving wallet or user.");
    					}
            	    }
            	    return Mono.empty();
            	    }).then();
      	  
      	  Mono<Void> handleWeaponRegisterCommand = gateway.on(MessageCreateEvent.class, event -> {
        	    Message message = event.getMessage();
        	    Integer temp;
        	    String msg = "";
        	    
        	    if (message.getContent().equalsIgnoreCase("!weaponregister")||message.getContent().startsWith("!wr")) {
        	    	try {
        	    		//If user who posted message has an existing wallet
        	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
						if(tempWallet!=null)
							{  
								String line = message.getContent();
	  							String[] strArr = new String[2];
								temp = line.indexOf(" ");
								strArr[0] = line.substring(0,temp);
								strArr[1] = line.substring(temp+1,line.length());
							//DEBUG: System.out.println(strArr[1]);
								WeaponService.registerWeapon(strArr[1]);
								msg += "Weapon '"+strArr[1]+"' has been registered!";
    							final String result = msg;
    							return message.getChannel()
											.flatMap(channel -> channel.createMessage(result));
    							
							
							}
						else
						{
		            	    return message.getChannel()
		                	        .flatMap(channel -> channel.createMessage("The recycler stands tall, ready to check through mud for anything of interest hidden inside. Set up a wallet to interact!"));
						}
					} catch (BusinessException e) {
						sLogger.log(Level.WARNING, e.getMessage());
						System.out.println("Error retrieving wallet or user.");
					}
        	    }
        	    return Mono.empty();
            	  }).then();
      	  
      	Mono<Void> handleMemeRegisterCommand = gateway.on(MessageCreateEvent.class, event -> {
    	    Message message = event.getMessage();
    	    Integer temp;
    	    String msg = "";
    	    
    	    if (message.getContent().equalsIgnoreCase("!memeregister")||message.getContent().startsWith("!mr")) {
    	    	try {
    	    		//If user who posted message has an existing wallet
    	    		Wallet tempWallet = WalletService.getWalletByUserId(UserService.getUserByDiscordId(message.getUserData().id().asString()).getId());
					if(tempWallet!=null)
						{  
							String line = message.getContent();
  							String[] strArr = new String[2];
							temp = line.indexOf(" ");
							strArr[0] = line.substring(0,temp);
							strArr[1] = line.substring(temp+1,line.length());
						//DEBUG: System.out.println(strArr[1]);
							MemeListService.registerMemeList(strArr[1]);
							msg += "Meme '"+strArr[1]+"' has been registered!";
							final String result = msg;
							return message.getChannel()
										.flatMap(channel -> channel.createMessage(result));
							
						
						}
					else
					{
	            	    return message.getChannel()
	                	        .flatMap(channel -> channel.createMessage("Error occured, try again"));
					}
				} catch (BusinessException e) {
					sLogger.log(Level.WARNING, e.getMessage());
					System.out.println("Error retrieving wallet or user.");
				}
    	    }
    	    return Mono.empty();
        	  }).then();

        	  
        	  Mono<Void> handleRegisterCommand = gateway.on(MessageCreateEvent.class, event -> {
          	    Message message = event.getMessage();
          	    Integer temp;
          	    net.db.hibernate.User tempUser;
          	    //ERROR FOUND: When new user is created does not accurately instantiate the correct fields, leading to errors when checking flags for FarmCheck or Mine
          	    if (message.getContent().equalsIgnoreCase("!register")) {
          	    	try {
						if(UserService.getUserByDiscordId(message.getUserData().id().asString())==null)
							{
							//Registering new user with provided data from the command
							temp = UserService.registerUser(message.getUserData().id().asString(),message.getUserData().username());
							//Registering wallet with new user created
							//Get added user
							tempUser = UserService.getUserByDiscordId(message.getUserData().id().asString());
							//Create wallet
	  							temp = WalletService.registerWallet(tempUser.getId());
	  							//Assign walletId to user
	  							tempUser.setWalletId(temp);
	  							//Create flags for use with wallet
	  							temp = FlagsService.registerFlags(tempUser.getId());
	  							//Assign flagsId to user and update
	  							tempUser.setFlagsId(temp);
	  							UserService.updateUser(tempUser);
							//Initializing flags
							return message.getChannel()
									.flatMap(channel -> channel.createMessage("Account created for ID `"+message.getUserData().id().asString()+"`! Welcome, "+message.getUserData().username()+"!"));
							}
					} catch (BusinessException e) {
						sLogger.log(Level.WARNING, e.getMessage());
						System.out.println("Error registering user.");
					}
          	      return message.getChannel()
          	          .flatMap(channel -> channel.createMessage("Account unable to be created, may already exist!"));
          	    }
          	    return Mono.empty();
          	  }).then();
        	  
        	  Mono<Void> handleRegisterWalletCommand = gateway.on(MessageCreateEvent.class, event -> {
            	    Message message = event.getMessage();
            	    Integer temp;
            	    net.db.hibernate.User tempUser;

            	    if (message.getContent().equalsIgnoreCase("!registerWallet")) {
            	    	try {
            	    	tempUser = UserService.getUserByDiscordId(message.getUserData().id().asString());
  						if(tempUser!=null)
  							{
  							if(WalletService.getWalletByUserId(tempUser.getId())==null)
  							{
  								//If User exists in DB but no wallet exists
  								//Create wallet
  	  							temp = WalletService.registerWallet(tempUser.getId());
  	  							//Assign walletId to user
  	  							tempUser.setWalletId(temp);
  	  							//Create flags for use with wallet
  	  							temp = FlagsService.registerFlags(tempUser.getId());
  	  							//Assign flagsId to user and update
  	  							tempUser.setFlagsId(temp);
  	  							UserService.updateUser(tempUser);
  	  							return message.getChannel()
  	  									.flatMap(channel -> channel.createMessage("Wallet created for "+message.getUserData().username()+"!"));
  	  							}
  							}
  							else
  							{
  								//If User exists in DB but wallet exists
  								return message.getChannel()
  			            	          .flatMap(channel -> channel.createMessage("Wallet unable to be created, already exists for this user!"));
  							}
  							
  					} catch (BusinessException e) {
  						sLogger.log(Level.WARNING, e.getMessage());
  						System.out.println("Error registering wallet.");
  					}
            	      return message.getChannel()
            	          .flatMap(channel -> channel.createMessage("Wallet unable to be created, user may not exist!"));
            	    }
            	    return Mono.empty();
            	  }).then();
        	  
        	  Mono<Void> handleWalletCommand = gateway.on(MessageCreateEvent.class, event -> {
          	    Message message = event.getMessage();
          	    Integer temp;
          	    net.db.hibernate.User tempUser;

          	    if (message.getContent().equalsIgnoreCase("!wallet")) {
          	    	try {
          	    	tempUser = UserService.getUserByDiscordId(message.getUserData().id().asString());
						if(tempUser!=null)
							{
							Wallet tempWallet = WalletService.getWalletByUserId(tempUser.getId());
							if(tempWallet!=null)
							{
								//If User exists in DB and wallet exists
								
	  							return message.getChannel()
	  									.flatMap(channel -> channel.createMessage(
	  											"--- "+message.getUserData().username()+"'s Wallet ---\n"
	  											  + "\t:coin: Int Coins: "+tempWallet.getIntCoins()+"\n"
	  											  + "\t<:Gold:943558944545181736> Glizzy Gold: "+tempWallet.getGlizzyGold()+"\n"
	  											  + "\t:gem: Dark Diamonds: "+tempWallet.getDarkDiamonds()+"\n"
	  											  + "\t:brown_square: Mud Pieces: "+tempWallet.getMudPieces()+"\n"
	  											  + "\t<:outDaMud:943658842972123176> Mud Artifacts: "+tempWallet.getMudArtifacts()+"\n"
	  											  + "\t:green_circle: Meme Dust: "+tempWallet.getMemeDust()+"\n"
	  											  + "\t:green_circle: Weapon Cores: "+tempWallet.getWeaponCores()+"\n"
	  											  + "\t:green_circle: Armor Cores: "+tempWallet.getArmorCores()+"\n"));
	  						}
							else
							{
								//If User exists in DB but wallet does not exist
								return message.getChannel()
			            	          .flatMap(channel -> channel.createMessage("Wallet does not exist for this user!"));
							}
							}
							else
							{
								//If User does not exist in DB
								return message.getChannel()
			            	          .flatMap(channel -> channel.createMessage("User has not registered!"));
							}
							
					} catch (BusinessException e) {
						sLogger.log(Level.WARNING, e.getMessage());
						System.out.println("Error registering wallet.");
					}
          	      return message.getChannel()
          	          .flatMap(channel -> channel.createMessage("Wallet unable to be created, user may not exist!"));
          	    }
          	    return Mono.empty();
          	  }).then();
        	  
        	  Mono<Void> handleTestRandomCommand = gateway.on(MessageCreateEvent.class, event -> {
            	    Message message = event.getMessage();
            	    Integer temp;
            	    net.db.hibernate.User tempUser;

            	    if (message.getContent().equalsIgnoreCase("!testRandom")||message.getContent().equalsIgnoreCase("!tr")) {
            	    	try {
            	    	tempUser = UserService.getUserByDiscordId(message.getUserData().id().asString());
  						if(tempUser!=null)
  							{
  							Wallet tempWallet = WalletService.getWalletByUserId(tempUser.getId());
  							if(tempWallet!=null)
  							{
  								//If User exists in DB and wallet exists
  								
  	  							return message.getChannel()
  	  									.flatMap(channel -> channel.createMessage(
  	  											"--- "+message.getUserData().username()+"'s Wallet ---\n"
  	  											  + "\t:coin: Int Coins: "+tempWallet.getIntCoins()+"\n"
  	  											  + "\t<:Gold:943558944545181736> Glizzy Gold: "+tempWallet.getGlizzyGold()+"\n"
  	  											  + "\t:gem: Dark Diamonds: "+tempWallet.getDarkDiamonds()+"\n"
  	  											  + "\t:brown_square: Mud Pieces: "+tempWallet.getMudPieces()+"\n"
  	  											  + "\t<:outDaMud:943658842972123176> Mud Artifacts: "+tempWallet.getMudArtifacts()+"\n"
  	  											  + "\t:green_circle: Meme Dust: "+tempWallet.getMemeDust()+"\n"
  	  											  + "\t:green_circle: Weapon Cores: "+tempWallet.getWeaponCores()+"\n"
  	  											  + "\t:green_circle: Armor Cores: "+tempWallet.getArmorCores()+"\n"));
  	  						}
  							else
  							{
  								//If User exists in DB but wallet does not exist
  								return message.getChannel()
  			            	          .flatMap(channel -> channel.createMessage("Wallet does not exist for this user!"));
  							}
  							}
  							else
  							{
  								//If User does not exist in DB
  								return message.getChannel()
  			            	          .flatMap(channel -> channel.createMessage("User has not registered!"));
  							}
  							
  					} catch (BusinessException e) {
  						sLogger.log(Level.WARNING, e.getMessage());
  						System.out.println("Error registering wallet.");
  					}
            	      return message.getChannel()
            	          .flatMap(channel -> channel.createMessage("Wallet unable to be created, user may not exist!"));
            	    }
            	    return Mono.empty();
            	  }).then();
        	  
        	  

        	  Mono<Void> tempListener = gateway.on(ButtonInteractionEvent.class, event -> {
        		  net.db.hibernate.User tempUser;
        		  Button responseButton = Button.success("testButton2", "Respond?");
	              if (event.getCustomId().equals("testButton")) {
	                  return event.edit("GOTCHA BITCH")
	                		  .withComponents(ActionRow.of(responseButton));
	              } else 
	            	  if (event.getCustomId().equals("testButton2")) {
		                  return event.edit("GOTCHA BITCH, WE CASCADIN!");
		              } else 
	            	  //if button for upgrading weapon is pressed
	              /*if (event.getCustomId().equals("upgradeWeapon")) {
	            	  try {
	            		  //attempt to get user that pushed the button
	            		  tempUser = UserService.getUserByDiscordId(event.getInteraction().getUser().getId().asString());
	            	  } catch (BusinessException e) {
	            		  sLogger.log(Level.WARNING, e.getMessage());
	            	  }
	            	  event.getInteraction().getUser().getId();
	                  return event.edit("GOTCHA BITCH"); } 
	              else */{
	                  // Ignore it
	                  return Mono.empty();
	              }
	          }).timeout(Duration.ofMinutes(5)) // Timeout after 5 minutes
	          // Handle TimeoutException that will be thrown when the above times out
	          .onErrorResume(TimeoutException.class, ignore -> Mono.empty())
	          .then(); //Transform the flux to a mono
        	  
        	  // combine them!
        	  return printOnLogin
        			  .and(tempListener)
        			  .and(handleBingBongCommand)
        			  .and(handleViewArmoryCommand)
        			  .and(handleViewMemeCommand)
        			  .and(handleArmoryDeleteCommand)
        			  .and(handleMemeDeleteCommand)
        			  .and(handleCheckTheMudCommand)
        			  .and(handleMineCommand)
        			  .and(handleFarmCheckCommand)
        			  .and(handleRecycleCommand)
        			  .and(handleWeaponMachineCommand)
        			  .and(handleMemeMachineCommand)
        			  .and(handleWeaponRegisterCommand)
        			  .and(handleMemeRegisterCommand)
        			  .and(handleRegisterCommand)
        			  .and(handleRegisterWalletCommand)
        			  .and(handleWalletCommand);
        	});
        
        login.block();
        
    }
}
