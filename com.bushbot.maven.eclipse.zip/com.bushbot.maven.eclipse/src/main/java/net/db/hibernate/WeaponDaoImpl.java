/**
 * 
 */
package net.db.hibernate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.db.hibernate.BaseDao;
import net.db.hibernate.WeaponDao;
import net.db.hibernate.Weapon;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-08
 * 
 */
public class WeaponDaoImpl extends BaseDao implements WeaponDao {

	@Override
	public void insertWeapon(Weapon weapon) throws Exception {
		weapon.setCreatedBy("BushBot");
		weapon.setModifiedBy("BushBot");
		/*weapon.setCreatedBy(getSessionWeapon());
		weapon.setModifiedBy(getSessionWeapon());*/
		insert(weapon);
	}

	@Override
	public Weapon getWeaponByName(String name) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("name", name);
		return getSingle("SELECT w FROM Weapon w WHERE name=:name", parameterMap, Weapon.class);
	}

	@Override
	public Weapon getWeaponById(Integer id) throws Exception {
		Weapon weapon = null;
		weapon = getSingle(id, Weapon.class);
		return weapon;
	}

	@Override
	public List<Weapon> getWeaponsByRarity(String rarity) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("rarity", rarity);
		return get("SELECT w FROM Weapon w WHERE rarity=:rarity", parameterMap, Weapon.class);
	}

	@Override
	public Weapon updateWeapon(Weapon weapon) throws Exception {
		//Currently not doing anything useful.
		/*Weapon dbWeapon = getSingle(weapon.getId(), Weapon.class);
		weapon.copyBaseProperties(dbWeapon);*/
		return update(weapon); 
	}

	@Override
	public void deleteWeapon(Integer id) throws Exception {
		delete(id, Weapon.class);
	}


}
