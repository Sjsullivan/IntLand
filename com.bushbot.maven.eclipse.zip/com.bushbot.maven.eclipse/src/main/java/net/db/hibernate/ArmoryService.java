/**
 * 
 */
package net.db.hibernate;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;

import net.db.hibernate.ArmoryDaoImpl;
import net.db.hibernate.ArmoryDao;
import net.db.hibernate.Armory;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-04-25
 *
 */
public class ArmoryService {
	private static final Logger sLogger = Logger.getLogger(ArmoryService.class.getName());
	
	/**
	 * Register Armory to system. Can be used for local authentication with supplied password
	 * @param Armory Armory to be registered in the system. Should also have required ArmoryProfile information
	 * @param password Password to register Armory with. Local authentication requires non-blank password
	 * @return Armory Id for registered Armory
	 * @throws BusinessException
	 */
	public static Integer registerArmory(Integer userId, Integer weaponId) throws BusinessException {

		Armory Armory = new Armory();
		try {
			ArmoryDao ArmoryDao = new ArmoryDaoImpl();
			Armory.setUserId(userId);
			Armory.setWeaponId(weaponId);
			Armory.setLevel(1);
			ArmoryDao.insertArmory(Armory);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error registering Armory.");
		}
		
		return Armory.getId();
	}
	
	/**
	 * Retrieve currently logged in Armory
	 * @return Armory currently logged in
	 * @throws BusinessException When there is an error retrieving the Armory, message should be safe to show Armory
	 */
	public static void updateArmory(Armory Armory) throws BusinessException {	
		try {
		ArmoryDao ArmoryDao = new ArmoryDaoImpl();
		ArmoryDao.updateArmory(Armory);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating Armory.");
		}
	}
	
	/**
	 * Retrieve Armory by Armory Id in system
	 * @param id Auto generated Id of the Armory in the system
	 * @return Armory with supplied id
	 * @throws BusinessException When there is an error retrieving the Armory, message should be safe to show Armory
	 */
	public static Armory getArmoryById(Integer id) throws BusinessException {
		if (id == null || id <= 0) {
			throw new BusinessException("Invalid Armory ID");
		}
		
		try {
			ArmoryDao ArmoryDao = new ArmoryDaoImpl();
			return ArmoryDao.getArmoryById(id);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid Armory ID");
		}
	}
	
	/**
	 * Retrieve Armory by supplied name address
	 * @param name Armorys unique name in the system 
	 * @return Armory with supplied name
	 * @throws BusinessException When there is an error retrieving the Armory, message should be safe to show Armory
	 */
	public static Armory getArmoryByName(String name) throws BusinessException {
		if (StringUtils.isBlank(name)) {
			throw new BusinessException("Name is blank");
		}
		
		try {
			ArmoryDao ArmoryDao = new ArmoryDaoImpl();
			return ArmoryDao.getArmoryByName(name);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid email");
		}
	}
	
	/**
	 * Retrieve Armories by supplied userId
	 * @param userId Armories' userId in the system 
	 * @return Armory List from supplied userId
	 * @throws BusinessException When there is an error retrieving the Armory, message should be safe to show Armory
	 */
	public static List<Armory> getArmorysByUserId(Integer userId) throws BusinessException {
		List<Armory> ArmoryList = null;
		try {
			ArmoryDao ArmoryDao = new ArmoryDaoImpl();
			ArmoryList = ArmoryDao.getArmorysByUserId(userId);
			return ArmoryList;
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			return ArmoryList;
		}
	}
}
