/**
 * 
 */
package net.db.hibernate;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;

import net.db.hibernate.WeaponDaoImpl;
import net.db.hibernate.WeaponDao;
import net.db.hibernate.Weapon;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-04-25
 *
 */
public class WeaponService {
	private static final Logger sLogger = Logger.getLogger(WeaponService.class.getName());
	
	/**
	 * Register weapon to system. Can be used for local authentication with supplied password
	 * @param weapon Weapon to be registered in the system. Should also have required WeaponProfile information
	 * @param password Password to register weapon with. Local authentication requires non-blank password
	 * @return Weapon Id for registered weapon
	 * @throws BusinessException
	 */
	public static Integer registerWeapon(String weaponname) throws BusinessException {

		Weapon weapon = new Weapon();
		try {
			WeaponDao weaponDao = new WeaponDaoImpl();
			weapon.setName(weaponname);
			weaponDao.insertWeapon(weapon);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error registering weapon.");
		}
		
		return weapon.getId();
	}
	
	/**
	 * Retrieve currently logged in weapon
	 * @return Weapon currently logged in
	 * @throws BusinessException When there is an error retrieving the weapon, message should be safe to show weapon
	 */
	public static void updateWeapon(Weapon weapon) throws BusinessException {	
		try {
		WeaponDao weaponDao = new WeaponDaoImpl();
		weaponDao.updateWeapon(weapon);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating weapon.");
		}
	}
	
	/**
	 * Retrieve Weapon by weapon Id in system
	 * @param id Auto generated Id of the weapon in the system
	 * @return Weapon with supplied id
	 * @throws BusinessException When there is an error retrieving the weapon, message should be safe to show weapon
	 */
	public static Weapon getWeaponById(Integer id) throws BusinessException {
		if (id == null || id <= 0) {
			throw new BusinessException("Invalid Weapon ID");
		}
		
		try {
			WeaponDao weaponDao = new WeaponDaoImpl();
			return weaponDao.getWeaponById(id);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid Weapon ID");
		}
	}
	
	/**
	 * Retrieve weapon by supplied name address
	 * @param name Weapons unique name in the system 
	 * @return Weapon with supplied name
	 * @throws BusinessException When there is an error retrieving the weapon, message should be safe to show weapon
	 */
	public static Weapon getWeaponByName(String name) throws BusinessException {
		if (StringUtils.isBlank(name)) {
			throw new BusinessException("Name is blank");
		}
		
		try {
			WeaponDao weaponDao = new WeaponDaoImpl();
			return weaponDao.getWeaponByName(name);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid email");
		}
	}
	
	/**
	 * Retrieve weapons by rarity
	 * @param rarity Rarity in the system 
	 * @return Weapons with supplied rarity
	 * @throws BusinessException When there is an error retrieving the weapons, message should be safe to show weapon
	 */
	public static List<Weapon> getWeaponsByRarity(String rarity) throws BusinessException {
		if (StringUtils.isBlank(rarity)) {
			throw new BusinessException("Rarity is blank");
		}
		List<Weapon> weaponList = null;
		try {
			WeaponDao weaponDao = new WeaponDaoImpl();
			weaponList = weaponDao.getWeaponsByRarity(rarity);
			return weaponList;
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			return weaponList;
		}
	}
}
