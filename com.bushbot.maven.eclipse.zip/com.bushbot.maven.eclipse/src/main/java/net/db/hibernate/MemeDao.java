/**
 * 
 */
package net.db.hibernate;

import java.util.List;

import net.db.hibernate.Meme;

/**
 * Meme access object for interaction with the database
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2023-05-14
 *
 */
public interface MemeDao {

	/**
	 * Insert new meme into database, passed in meme object will be updated with new
	 * generated id upon success
	 * @param meme System meme to be inserted into database with non-null MemeProfile
	 *             pre-populated
	 * @throws Exception If there was an issue inserting object and there was also a
	 *                   problem during rollback transaction or Database connection
	 *                   is closed
	 */
	public void insertMeme(Meme meme) throws Exception;

	/**
	 * Retrieves a meme with supplied name
	 * @param memename Memes' name
	 * @return Meme with supplied name
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Meme getMemeByName(String name) throws Exception;

	/**
	 * Retrieves a meme with supplied meme id
	 * @param id Memes' auto-generated id in the system
	 * @return Meme with supplied email address
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Meme getMemeById(Integer id) throws Exception;
	
	/**
	 * Retrieves all memes with supplied userId
	 * THIS GRABS ALL OF THE USER'S WEAPONS (as armories, weapon instances.)
	 * @param userId userId for memes
	 * @return Memes with supplied userId
	 * @throws Exception If there was an issue retrieving objects or Database connection
	 *                   is closed
	 */
	public List<Meme> getMemesByUserId(Integer userId) throws Exception;
	
	/**
	 * Retrieves all memes with supplied rarity
	 * @param rarity rarity for memes
	 * @return Memes with supplied rarity
	 * @throws Exception If there was an issue retrieving objects or Database connection
	 *                   is closed
	 */
	public List<Meme> getMemesByRarity(String rarity) throws Exception;

	/**
	 * Updates a meme with new information
	 * @param meme new object with new information
	 * @return Updated meme
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Meme updateMeme(Meme meme) throws Exception;

	/**
	 * Permanently removed a meme from the system with provided id
	 * @param id Meme id of the meme to remove
	 * @throws Exception If there was an issue removing object or Database connection
	 *                   is closed
	 */
	public void deleteMeme(Integer id) throws Exception;


}
