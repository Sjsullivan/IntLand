package net.db.hibernate;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * The base class for all tables which hold common components.
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-07
 *
 */
@Data
@MappedSuperclass
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@EqualsAndHashCode.Exclude
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(unique = true, nullable = false)
	private Integer id;

	@EqualsAndHashCode.Exclude
	@Column(nullable = false)
	private String createdBy;

	@EqualsAndHashCode.Exclude
	@CreationTimestamp
	private LocalDateTime creationOn;

	@EqualsAndHashCode.Exclude
	@Column(nullable = false)
	private String modifiedBy;

	@EqualsAndHashCode.Exclude
	@UpdateTimestamp
	private LocalDateTime modifiedOn;

	public <T extends BaseModel> void copyBaseProperties(final T object)
			throws IllegalAccessException, InvocationTargetException {
		this.setId(object.getId());
		this.setCreatedBy(object.getCreatedBy());
		this.setCreationOn(object.getCreationOn());
		this.setModifiedBy(object.getModifiedBy());
		this.setModifiedOn(object.getModifiedOn());
	}
}
