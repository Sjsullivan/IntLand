package net.db.hibernate;
// Rarity Apr 25, 2022, 12:23:00 PM by Hibernate Tools 5.6.3.Final

import java.util.HashSet;
import java.util.Set;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * MemeList rarity by hbm2java
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@NamedQuery(name = "MemeList.findAll", query = "SELECT ml FROM MemeList ml")
public class MemeList extends BaseModel implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	private Integer id;
	private String name;
	private Integer evoLevel;
	private Integer evoPrevious;
	private Integer evoNext;
	private String rarity;
	private LocalDateTime creationOn;
	private String createdBy;
	private LocalDateTime modifiedOn;
	private String modifiedBy;

	public MemeList() {
	}

	public MemeList(String name, Integer evoLevel, Integer evoPrevious, Integer evoNext, String rarity,
			LocalDateTime creationOn, String createdBy, LocalDateTime modifiedOn, String modifiedBy) {
		this.name = name;
		this.evoLevel = evoLevel;
		this.evoPrevious = evoPrevious;
		this.evoNext = evoNext;
		this.rarity = rarity;
		this.creationOn = creationOn;
		this.createdBy = createdBy;
		this.modifiedOn = modifiedOn;
		this.modifiedBy = modifiedBy;
	}

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getEvoLevel() {
		return this.evoLevel;
	}

	public void setEvoLevel(Integer evoLevel) {
		this.evoLevel = evoLevel;
	}

	public Integer getEvoPrevious() {
		return this.evoPrevious;
	}

	public void setEvoPrevious(Integer evoPrevious) {
		this.evoPrevious = evoPrevious;
	}

	public Integer getEvoNext() {
		return this.evoNext;
	}

	public void setEvoNext(Integer evoNext) {
		this.evoNext = evoNext;
	}

	public String getRarity() {
		return this.rarity;
	}

	public void setRarity(String rarity) {
		this.rarity = rarity;
	}

	public LocalDateTime getCreationOn() {
		return this.creationOn;
	}

	public void setCreationOn(LocalDateTime creationOn) {
		this.creationOn = creationOn;
	}

	public String getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getModifiedOn() {
		return this.modifiedOn;
	}

	public void setModifiedOn(LocalDateTime modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return this.modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
