/**
 * 
 */
package net.db.hibernate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.db.hibernate.BaseDao;
import net.db.hibernate.ArmoryDao;
import net.db.hibernate.Armory;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-04-27
 * 
 */
public class ArmoryDaoImpl extends BaseDao implements ArmoryDao {

	@Override
	public void insertArmory(Armory armory) throws Exception {
		armory.setCreatedBy("BushBot");
		armory.setModifiedBy("BushBot");
		/*armory.setCreatedBy(getSessionArmory());
		armory.setModifiedBy(getSessionArmory());*/
		insert(armory);
	}

	@Override
	public Armory getArmoryByName(String name) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("name", name);
		return getSingle("SELECT ar FROM Armory ar WHERE name=:name", parameterMap, Armory.class);
	}

	@Override
	public Armory getArmoryById(Integer id) throws Exception {
		Armory armory = null;
		armory = getSingle(id, Armory.class);
		return armory;
	}

	@Override
	public List<Armory> getArmorysByUserId(Integer userId) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("userId", userId);
		return get("SELECT ar FROM Armory ar WHERE userId=:userId", parameterMap, Armory.class);
	}
	
	@Override
	public List<Armory> getArmorysByRarity(String rarity) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("rarity", rarity);
		return get("SELECT ar FROM Armory ar WHERE rarity=:rarity", parameterMap, Armory.class);
	}

	@Override
	public Armory updateArmory(Armory armory) throws Exception {
		//Currently not doing anything useful.
		/*Armory dbArmory = getSingle(armory.getId(), Armory.class);
		armory.copyBaseProperties(dbArmory);*/
		return update(armory); 
	}

	@Override
	public void deleteArmory(Integer id) throws Exception {
		delete(id, Armory.class);
	}


}
