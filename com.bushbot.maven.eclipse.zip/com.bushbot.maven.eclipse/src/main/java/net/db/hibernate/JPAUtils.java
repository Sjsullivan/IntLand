/**
 * 
 */
package net.db.hibernate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-07
 *
 */
public class JPAUtils {
	private static final EntityManagerFactory entityManagerFactory;
	
	/**
	 * Intentionally private constructor
	 */
	private JPAUtils() {
		throw new IllegalStateException("Utility class should not be initiated");
	}

	static {
		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("IntLand");
		} catch (Throwable ex) {
			throw new ExceptionInInitializerError(ex);
		}
	}

	public static EntityManager getEntityManager() {
		return entityManagerFactory.createEntityManager();

	}
}
