/**
 * 
 */
package net.db.hibernate;

import java.util.List;

import net.db.hibernate.User;

/**
 * Wallet access object for interaction with the database
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-08
 *
 */
public interface WalletDao {

	/**
	 * Insert new wallet into database, passed in wallet object will be updated with new
	 * generated id upon success
	 * @param wallet System wallet to be inserted into database with default values
	 *             pre-populated
	 * @throws Exception If there was an issue inserting object and there was also a
	 *                   problem during rollback transaction or Database connection
	 *                   is closed
	 */
	public void insertWallet(Wallet wallet) throws Exception;

	/**
	 * Retrieves a wallet with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @return Wallet with supplied idy
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Wallet getWalletById(Integer id) throws Exception;
	
	/**
	 * Retrieves a wallet with supplied user id
	 * @param userId User id of wallet in the system
	 * @return Wallet with supplied userId
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Wallet getWalletByUserId(Integer id) throws Exception;
	
	/**
	 * Retrieves IntCoins with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @return IntCoins from wallet with supplied id
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Integer getIntCoinsById(Integer id) throws Exception;
	
	/**
	 * Sets IntCoins with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public void setIntCoinsById(Integer id, Integer amount) throws Exception;
	
	/**
	 * Retrieves GlizzyGold with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @return GlizzyGold from wallet with supplied id
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Integer getGlizzyGoldById(Integer id) throws Exception;
	
	/**
	 * Sets GlizzyGold with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public void setGlizzyGoldById(Integer id, Integer amount) throws Exception;
	
	/**
	 * Retrieves DarkDiamonds with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @return DarkDiamonds from wallet with supplied id
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Integer getDarkDiamondsById(Integer id) throws Exception;
	
	/**
	 * Sets DarkDiamonds with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public void setDarkDiamondsById(Integer id, Integer amount) throws Exception;
	
	/**
	 * Retrieves MudPieces with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @return MudPieces from wallet with supplied id
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Integer getMudPiecesById(Integer id) throws Exception;
	
	/**
	 * Sets MudPieces with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public void setMudPiecesById(Integer id, Integer amount) throws Exception;
	
	/**
	 * Retrieves MudArtifacts with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @return MudArtifacts from wallet with supplied id
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Integer getMudArtifactsById(Integer id) throws Exception;
	
	/**
	 * Sets MudArtifacts with supplied wallet id
	 * @param id Wallet's auto-generated id in the system
	 * @return MudArtifacts from wallet with supplied id
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public void setMudArtifactsById(Integer id, Integer amount) throws Exception;
	
	/**
	 * Retrieves all currencies in wallet with supplied wallet id
	 * @param id Wallet id for currencies
	 * @return Currencies in wallet with supplied wallet id
	 * @throws Exception If there was an issue retrieving objects or Database connection
	 *                   is closed
	 */
	//public List<Integer> getContentsOfWallet(Integer id) throws Exception;

	/**
	 * Updates a wallet with new information
	 * @param wallet new object with new information
	 * @return Updated wallet
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Wallet updateWallet(Wallet wallet) throws Exception;

	/**
	 * Permanently remove a wallet from the system with provided id
	 * @param id Wallet id of the wallet to remove
	 * @throws Exception If there was an issue removing object or Database connection
	 *                   is closed
	 */
	public void deleteWallet(Integer id) throws Exception;


}
