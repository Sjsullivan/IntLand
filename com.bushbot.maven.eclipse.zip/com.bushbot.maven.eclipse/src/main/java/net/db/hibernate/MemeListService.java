/**
 * 
 */
package net.db.hibernate;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;

import net.db.hibernate.MemeListDaoImpl;
import net.db.hibernate.MemeListDao;
import net.db.hibernate.MemeList;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2023-05-14
 *
 */
public class MemeListService {
	private static final Logger sLogger = Logger.getLogger(MemeListService.class.getName());
	
	/**
	 * Register memeList to system. Can be used for local authentication with supplied password
	 * @param memeList MemeList to be registered in the system. Should also have required MemeListProfile information
	 * @param password Password to register memeList with. Local authentication requires non-blank password
	 * @return MemeList Id for registered memeList
	 * @throws BusinessException
	 */
	public static Integer registerMemeList(String memeListname) throws BusinessException {

		MemeList memeList = new MemeList();
		try {
			MemeListDao memeListDao = new MemeListDaoImpl();
			memeList.setName(memeListname);
			memeListDao.insertMemeList(memeList);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error registering memeList.");
		}
		
		return memeList.getId();
	}
	
	/**
	 * Retrieve currently logged in memeList
	 * @return MemeList currently logged in
	 * @throws BusinessException When there is an error retrieving the memeList, message should be safe to show memeList
	 */
	public static void updateMemeList(MemeList memeList) throws BusinessException {	
		try {
		MemeListDao memeListDao = new MemeListDaoImpl();
		memeListDao.updateMemeList(memeList);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating memeList.");
		}
	}
	
	/**
	 * Retrieve MemeList by memeList Id in system
	 * @param id Auto generated Id of the memeList in the system
	 * @return MemeList with supplied id
	 * @throws BusinessException When there is an error retrieving the memeList, message should be safe to show memeList
	 */
	public static MemeList getMemeListById(Integer id) throws BusinessException {
		if (id == null || id <= 0) {
			throw new BusinessException("Invalid MemeList ID");
		}
		
		try {
			MemeListDao memeListDao = new MemeListDaoImpl();
			return memeListDao.getMemeListById(id);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid MemeList ID");
		}
	}
	
	/**
	 * Retrieve memeList by supplied name address
	 * @param name MemeLists unique name in the system 
	 * @return MemeList with supplied name
	 * @throws BusinessException When there is an error retrieving the memeList, message should be safe to show memeList
	 */
	public static MemeList getMemeListByName(String name) throws BusinessException {
		if (StringUtils.isBlank(name)) {
			throw new BusinessException("Name is blank");
		}
		
		try {
			MemeListDao memeListDao = new MemeListDaoImpl();
			return memeListDao.getMemeListByName(name);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid email");
		}
	}
	
	/**
	 * Retrieve memeLists by rarity
	 * @param rarity Rarity in the system 
	 * @return MemeLists with supplied rarity
	 * @throws BusinessException When there is an error retrieving the memeLists, message should be safe to show memeList
	 */
	public static List<MemeList> getMemeListsByRarity(String rarity) throws BusinessException {
		if (StringUtils.isBlank(rarity)) {
			throw new BusinessException("Rarity is blank");
		}
		List<MemeList> memeListList = null;
		List<MemeList> finalMemeListList = new ArrayList<MemeList>();
		try {
			MemeListDao memeListDao = new MemeListDaoImpl();
			memeListList = memeListDao.getMemeListsByRarity(rarity);
			//Trim rarity list to only include non-evolutions
			for(MemeList meme : memeListList)
			{
				if(meme.getEvoPrevious()== null)
				{
					finalMemeListList.add(meme);
				}
			}
			return (List<MemeList>)finalMemeListList;
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			return memeListList;
		}
	}
}
