/**
 * 
 */
package net.db.hibernate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.db.hibernate.BaseDao;
import net.db.hibernate.MemeListDao;
import net.db.hibernate.MemeList;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2023-05-14
 * 
 */
public class MemeListDaoImpl extends BaseDao implements MemeListDao {

	@Override
	public void insertMemeList(MemeList memeList) throws Exception {
		memeList.setCreatedBy("BushBot");
		memeList.setModifiedBy("BushBot");
		/*memeList.setCreatedBy(getSessionMemeList());
		memeList.setModifiedBy(getSessionMemeList());*/
		insert(memeList);
	}

	@Override
	public MemeList getMemeListByName(String name) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("name", name);
		return getSingle("SELECT ml FROM MemeList ml WHERE name=:name", parameterMap, MemeList.class);
	}

	@Override
	public MemeList getMemeListById(Integer id) throws Exception {
		MemeList memeList = null;
		memeList = getSingle(id, MemeList.class);
		return memeList;
	}

	@Override
	public List<MemeList> getMemeListsByRarity(String rarity) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("rarity", rarity);
		//REMINDER: trim rarity list to only include non-evolved memes in MemeListService/MemeService
		return get("SELECT ml FROM MemeList ml WHERE rarity=:rarity", parameterMap, MemeList.class);
	}

	@Override
	public MemeList updateMemeList(MemeList memeList) throws Exception {
		//Currently not doing anything useful.
		/*MemeList dbMemeList = getSingle(memeList.getId(), MemeList.class);
		memeList.copyBaseProperties(dbMemeList);*/
		return update(memeList); 
	}

	@Override
	public void deleteMemeList(Integer id) throws Exception {
		delete(id, MemeList.class);
	}


}
