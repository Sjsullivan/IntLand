/**
 * 
 */
package net.db.hibernate;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;

import net.db.hibernate.UserDaoImpl;
import net.db.hibernate.UserDao;
import net.db.hibernate.User;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-29
 *
 */
public class FlagsService {
	private static final Logger sLogger = Logger.getLogger(UserService.class.getName());
	
	/**
	 * Register flags to system. 
	 * @param flags Flags to be registered in the system.
	 * @return Flags Id for registered flags
	 * @throws BusinessException
	 */
	public static Integer registerFlags(int userId) throws BusinessException {

		Flags flags = new Flags();
		try {
			FlagsDao flagsDao = new FlagsDaoImpl();
			flags.setUserId(userId);
			flagsDao.insertFlags(flags);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error registering flags.");
		}
		
		return flags.getId();
	}
	
	/**
	 * Retrieve currently logged in flags
	 * @return Flags currently logged in
	 * @throws BusinessException When there is an error retrieving the flags, message should be safe to show flags
	 */
	public static void updateFlags(Flags flags) throws BusinessException {	
		try {
		FlagsDao flagsDao = new FlagsDaoImpl();
		flagsDao.updateFlags(flags);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating flags.");
		}
	}
	
	/**
	 * Retrieve currently logged in flags
	 * @return Flags currently logged in
	 * @throws BusinessException When there is an error retrieving the flags, message should be safe to show flags
	 */
	public static Flags getCurrentFlags() throws BusinessException {	
		return getFlagsById((int) SecurityUtils.getSubject().getPrincipal());
	}
	
	/**
	 * Retrieve Flags by flags Id in system
	 * @param id Auto generated Id of the flags in the system
	 * @return Flags with supplied id
	 * @throws BusinessException When there is an error retrieving the flags, message should be safe to show flags
	 */
	public static Flags getFlagsById(Integer id) throws BusinessException {
		if (id == null || id <= 0) {
			throw new BusinessException("Invalid Flags ID");
		}
		
		try {
			FlagsDao flagsDao = new FlagsDaoImpl();
			return flagsDao.getFlagsById(id);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid Flags ID");
		}
	}
	
	/**
	 * Retrieve flags by supplied discordId address
	 * @param discordId Flags unique discordId in the system 
	 * @return Flags with supplied discordId
	 * @throws BusinessException When there is an error retrieving the flags, message should be safe to show flags
	 */
	public static Flags getFlagsByUserId(Integer userId) throws BusinessException {
		Flags flags = null;
		try {
			FlagsDao flagsDao = new FlagsDaoImpl();
			flags = flagsDao.getFlagsByUserId(userId);
			return flags;
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			return flags;
		}
	}
}
