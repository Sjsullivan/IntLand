package net.db.hibernate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.db.hibernate.BaseDao;
import net.db.hibernate.WalletDao;
import net.db.hibernate.Wallet;

/**
 * Implementation of Wallet access object for interaction with the database
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-08
 *
 */
public class WalletDaoImpl extends BaseDao implements WalletDao {

	@Override
	public void insertWallet(Wallet wallet) throws Exception
	{
		wallet.setCreatedBy("BushBot");
		wallet.setModifiedBy("BushBot");
		insert(wallet);
	}

	@Override
	public Wallet getWalletById(Integer id) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		return wallet;
	}
	
	@Override
	public Wallet getWalletByUserId(Integer userId) throws Exception
	{
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("userId", userId);
		return getSingle("SELECT w FROM Wallet w WHERE userId=:userId", parameterMap, Wallet.class);
	}
	
	@Override
	public Integer getIntCoinsById(Integer id) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		return wallet.getIntCoins();
	}
	
	@Override
	public void setIntCoinsById(Integer id, Integer amount) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		wallet.setIntCoins(amount);
		update(wallet); 
	}
	
	@Override
	public Integer getGlizzyGoldById(Integer id) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		return wallet.getGlizzyGold();
	}
	
	@Override
	public void setGlizzyGoldById(Integer id, Integer amount) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		wallet.setGlizzyGold(amount);
		update(wallet);
	}
	
	@Override
	public Integer getDarkDiamondsById(Integer id) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		return wallet.getDarkDiamonds();
	}
	
	@Override
	public void setDarkDiamondsById(Integer id, Integer amount) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		wallet.setDarkDiamonds(amount);
		update(wallet);
	}
	
	@Override
	public Integer getMudPiecesById(Integer id) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		return wallet.getMudPieces();
	}
	
	@Override
	public void setMudPiecesById(Integer id, Integer amount) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		wallet.setMudPieces(amount);
		update(wallet);
	}
	
	@Override
	public Integer getMudArtifactsById(Integer id) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		return wallet.getMudArtifacts();
	}
	
	@Override
	public void setMudArtifactsById(Integer id, Integer amount) throws Exception
	{
		Wallet wallet = null;
		wallet = getSingle(id, Wallet.class);
		wallet.setMudArtifacts(amount);
		update(wallet);
	}
	
	/*public List<Integer> getContentsOfWallet(Integer id) throws Exception
	{
		
	}*/

	@Override
	public Wallet updateWallet(Wallet wallet) throws Exception
	{
		return update(wallet);
	}

	@Override
	public void deleteWallet(Integer id) throws Exception
	{
		delete(id, Wallet.class);
	}

	
}
