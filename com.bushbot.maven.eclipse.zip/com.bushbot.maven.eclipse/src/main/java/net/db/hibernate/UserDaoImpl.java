/**
 * 
 */
package net.db.hibernate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.db.hibernate.BaseDao;
import net.db.hibernate.UserDao;
import net.db.hibernate.User;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-08
 * 
 */
public class UserDaoImpl extends BaseDao implements UserDao {

	@Override
	public void insertUser(User user) throws Exception {
		user.setCreatedBy("BushBot");
		user.setModifiedBy("BushBot");
		/*user.setCreatedBy(getSessionUser());
		user.setModifiedBy(getSessionUser());*/
		insert(user);
	}

	@Override
	public User getUserByUsername(String username) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("username", username);
		return getSingle("SELECT u FROM User u WHERE username=:username", parameterMap, User.class);
	}

	@Override
	public User getUserById(Integer id) throws Exception {
		User user = null;
		user = getSingle(id, User.class);
		return user;
	}
	
	@Override
	public User getUserByDiscordId(String discordId) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("discordId", discordId);
		return getSingle("SELECT u FROM User u WHERE discordId=:discordId", parameterMap, User.class);
	}
	
	@Override
	public User getUserByWalletId(Integer walletId) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("walletId", walletId);
		return getSingle("SELECT u FROM User u WHERE walletId=:walletId", parameterMap, User.class);
	}
	
	@Override
	public User getUserByCollectionId(Integer collectionId) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("collectionId", collectionId);
		return getSingle("SELECT u FROM User u WHERE collectionId=:collectionId", parameterMap, User.class);
	}
	
	@Override
	public User getUserByFlagsId(Integer flagsId) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("flagsId", flagsId);
		return getSingle("SELECT u FROM User u WHERE flagsId=:flagsId", parameterMap, User.class);
	}

	@Override
	public List<User> getUsersByRole(Integer id) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("roleId", id);
		return get("SELECT u FROM User u WHERE roleId=:roleId", parameterMap, User.class);
	}

	@Override
	public User updateUser(User user) throws Exception {
		//Currently not doing anything useful.
		/*User dbUser = getSingle(user.getId(), User.class);
		user.copyBaseProperties(dbUser);*/
		return update(user); 
	}

	@Override
	public void deleteUser(Integer id) throws Exception {
		delete(id, User.class);
	}


}
