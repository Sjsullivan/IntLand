/**
 * 
 */
package net.db.hibernate;

import java.util.List;

import net.db.hibernate.MemeList;

/**
 * MemeList access object for interaction with the database
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2023-05-14
 *
 */
public interface MemeListDao {

	/**
	 * Insert new memeList into database, passed in memeList object will be updated with new
	 * generated id upon success
	 * @param memeList System memeList to be inserted into database with non-null MemeListProfile
	 *             pre-populated
	 * @throws Exception If there was an issue inserting object and there was also a
	 *                   problem during rollback transaction or Database connection
	 *                   is closed
	 */
	public void insertMemeList(MemeList memeList) throws Exception;

	/**
	 * Retrieves a memeList with supplied name
	 * @param memeListname MemeLists' name
	 * @return MemeList with supplied name
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public MemeList getMemeListByName(String name) throws Exception;

	/**
	 * Retrieves a memeList with supplied memeList id
	 * @param id MemeLists' auto-generated id in the system
	 * @return MemeList with supplied email address
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public MemeList getMemeListById(Integer id) throws Exception;
	
	/**
	 * Retrieves all memeLists with supplied rarity
	 * @param rarity rarity for memeLists
	 * @return MemeLists with supplied rarity
	 * @throws Exception If there was an issue retrieving objects or Database connection
	 *                   is closed
	 */
	public List<MemeList> getMemeListsByRarity(String rarity) throws Exception;

	/**
	 * Updates a memeList with new information
	 * @param memeList new object with new information
	 * @return Updated memeList
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public MemeList updateMemeList(MemeList memeList) throws Exception;

	/**
	 * Permanently removed a memeList from the system with provided id
	 * @param id MemeList id of the memeList to remove
	 * @throws Exception If there was an issue removing object or Database connection
	 *                   is closed
	 */
	public void deleteMemeList(Integer id) throws Exception;


}
