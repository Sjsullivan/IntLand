/**
 * 
 */
package net.db.hibernate;

import java.util.List;

import net.db.hibernate.Armory;

/**
 * Armory access object for interaction with the database
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-04-25
 *
 */
public interface ArmoryDao {

	/**
	 * Insert new armory into database, passed in armory object will be updated with new
	 * generated id upon success
	 * @param armory System armory to be inserted into database with non-null ArmoryProfile
	 *             pre-populated
	 * @throws Exception If there was an issue inserting object and there was also a
	 *                   problem during rollback transaction or Database connection
	 *                   is closed
	 */
	public void insertArmory(Armory armory) throws Exception;

	/**
	 * Retrieves a armory with supplied name
	 * @param armoryname Armorys' name
	 * @return Armory with supplied name
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Armory getArmoryByName(String name) throws Exception;

	/**
	 * Retrieves a armory with supplied armory id
	 * @param id Armorys' auto-generated id in the system
	 * @return Armory with supplied email address
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Armory getArmoryById(Integer id) throws Exception;
	
	/**
	 * Retrieves all armorys with supplied userId
	 * THIS GRABS ALL OF THE USER'S WEAPONS (as armories, weapon instances.)
	 * @param userId userId for armorys
	 * @return Armorys with supplied userId
	 * @throws Exception If there was an issue retrieving objects or Database connection
	 *                   is closed
	 */
	public List<Armory> getArmorysByUserId(Integer userId) throws Exception;
	
	/**
	 * Retrieves all armorys with supplied rarity
	 * @param rarity rarity for armorys
	 * @return Armorys with supplied rarity
	 * @throws Exception If there was an issue retrieving objects or Database connection
	 *                   is closed
	 */
	public List<Armory> getArmorysByRarity(String rarity) throws Exception;

	/**
	 * Updates a armory with new information
	 * @param armory new object with new information
	 * @return Updated armory
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Armory updateArmory(Armory armory) throws Exception;

	/**
	 * Permanently removed a armory from the system with provided id
	 * @param id Armory id of the armory to remove
	 * @throws Exception If there was an issue removing object or Database connection
	 *                   is closed
	 */
	public void deleteArmory(Integer id) throws Exception;


}
