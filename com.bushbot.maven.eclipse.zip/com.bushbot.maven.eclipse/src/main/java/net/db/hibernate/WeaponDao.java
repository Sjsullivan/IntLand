/**
 * 
 */
package net.db.hibernate;

import java.util.List;

import net.db.hibernate.Weapon;

/**
 * Weapon access object for interaction with the database
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-04-25
 *
 */
public interface WeaponDao {

	/**
	 * Insert new weapon into database, passed in weapon object will be updated with new
	 * generated id upon success
	 * @param weapon System weapon to be inserted into database with non-null WeaponProfile
	 *             pre-populated
	 * @throws Exception If there was an issue inserting object and there was also a
	 *                   problem during rollback transaction or Database connection
	 *                   is closed
	 */
	public void insertWeapon(Weapon weapon) throws Exception;

	/**
	 * Retrieves a weapon with supplied name
	 * @param weaponname Weapons' name
	 * @return Weapon with supplied name
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Weapon getWeaponByName(String name) throws Exception;

	/**
	 * Retrieves a weapon with supplied weapon id
	 * @param id Weapons' auto-generated id in the system
	 * @return Weapon with supplied email address
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Weapon getWeaponById(Integer id) throws Exception;
	
	/**
	 * Retrieves all weapons with supplied rarity
	 * @param rarity rarity for weapons
	 * @return Weapons with supplied rarity
	 * @throws Exception If there was an issue retrieving objects or Database connection
	 *                   is closed
	 */
	public List<Weapon> getWeaponsByRarity(String rarity) throws Exception;

	/**
	 * Updates a weapon with new information
	 * @param weapon new object with new information
	 * @return Updated weapon
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Weapon updateWeapon(Weapon weapon) throws Exception;

	/**
	 * Permanently removed a weapon from the system with provided id
	 * @param id Weapon id of the weapon to remove
	 * @throws Exception If there was an issue removing object or Database connection
	 *                   is closed
	 */
	public void deleteWeapon(Integer id) throws Exception;


}
