/**
 * 
 */
package net.db.hibernate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.db.hibernate.BaseDao;
import net.db.hibernate.MemeDao;
import net.db.hibernate.Meme;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2023-05-14
 * 
 */
public class MemeDaoImpl extends BaseDao implements MemeDao {

	@Override
	public void insertMeme(Meme meme) throws Exception {
		meme.setCreatedBy("BushBot");
		meme.setModifiedBy("BushBot");
		/*meme.setCreatedBy(getSessionMeme());
		meme.setModifiedBy(getSessionMeme());*/
		insert(meme);
	}

	@Override
	public Meme getMemeByName(String name) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("name", name);
		return getSingle("SELECT me FROM Meme me WHERE name=:name", parameterMap, Meme.class);
	}

	@Override
	public Meme getMemeById(Integer id) throws Exception {
		Meme meme = null;
		meme = getSingle(id, Meme.class);
		return meme;
	}

	@Override
	public List<Meme> getMemesByUserId(Integer userId) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("userId", userId);
		return get("SELECT me FROM Meme me WHERE userId=:userId", parameterMap, Meme.class);
	}
	
	@Override
	public List<Meme> getMemesByRarity(String rarity) throws Exception {
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("rarity", rarity);
		return get("SELECT me FROM Meme me WHERE rarity=:rarity", parameterMap, Meme.class);
	}

	@Override
	public Meme updateMeme(Meme meme) throws Exception {
		//Currently not doing anything useful.
		/*Meme dbMeme = getSingle(meme.getId(), Meme.class);
		meme.copyBaseProperties(dbMeme);*/
		return update(meme); 
	}

	@Override
	public void deleteMeme(Integer id) throws Exception {
		delete(id, Meme.class);
	}


}
