/**
 * 
 */
package net.db.hibernate;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.apache.shiro.SecurityUtils;

import net.db.hibernate.BaseModel;
import net.db.hibernate.JPAUtils;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-07
 *
 */
public class BaseDao {
	private static final Logger sLogger = Logger.getLogger(BaseDao.class.getName());
	
	/**
	 * Retrieves the id of current current user to be used for database auditing 
	 * @return User if from the current session or "System" if user id not present
	 */
	protected static String getSessionUser() {
		String userString;
		try {
			userString = ((Long) SecurityUtils.getSubject().getPrincipal()).toString();
		} catch (Exception e) {
			sLogger.log(Level.FINEST, e.getMessage());
			userString = "System";
		}
		return userString;
	}
	
	protected static <T> T getSingle(final int id, final Class<T> type) {
		EntityManager entityManager = null;
		T object = null;
		try {
			entityManager = JPAUtils.getEntityManager();
			object = (T) entityManager.find(type, id);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage(), e);
			throw e;
		} finally {
			if (entityManager != null)
				entityManager.close();
		}
		return object;
	}
	
	protected static <T> T getSingle(final String queryString, final Class<T> type) {
		return getSingle(queryString, null, type);
	}
	
	protected static <T> T getSingle(final String queryString, final Map<String, Object> parameters, final Class<T> type) {
		EntityManager entityManager = null;
		T result = null;
		try {
			entityManager = JPAUtils.getEntityManager();
			TypedQuery<T> query = entityManager.createQuery(queryString, type);
			if (parameters != null && !parameters.isEmpty()) {
				for (final String keyString : parameters.keySet()) {
					query.setParameter(keyString, parameters.get(keyString));
				}
			}
			result = query.getSingleResult();
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw e;
		} finally {
			if (entityManager != null)
				entityManager.close();
		}
		return result;
	}
	
	protected static <T> List<T> get(final String queryString, final Class<T> type) {
		return get(queryString, null, type);
	}
	
	protected static <T> List<T> get(final String queryString, final Map<String, Object> parameters, final Class<T> type) {
		EntityManager entityManager = null;
		List<T> result = new ArrayList<T>();
		try {
			entityManager = JPAUtils.getEntityManager();
			TypedQuery<T> query = entityManager.createQuery(queryString, type);
			if (parameters != null && !parameters.isEmpty()) {
				for (final String keyString : parameters.keySet()) {
					query.setParameter(keyString, parameters.get(keyString));
				}
			}
			result = query.getResultList();
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage(), e);
			throw e;
		} finally {
			if (entityManager != null)
				entityManager.close();
		}
		return result;
	}

	protected static <T> void insert(final T object) {
		EntityManager entityManager = null;
		try {
			entityManager = JPAUtils.getEntityManager();
			entityManager.getTransaction().begin();
			((BaseModel) object).setCreatedBy(getSessionUser());
			((BaseModel) object).setModifiedBy(getSessionUser());
			entityManager.persist(object);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage(), e);
			entityManager.getTransaction().rollback();
			throw e;
		} finally {
			if (entityManager != null)
				entityManager.close();
		}
	}
	
	protected static <T> void insert(final List<T> objectList) {
		EntityManager entityManager = null;
		try {
			entityManager = JPAUtils.getEntityManager();
			entityManager.getTransaction().begin();
			for (T object: objectList) {
				((BaseModel) object).setCreatedBy(getSessionUser());
				((BaseModel) object).setModifiedBy(getSessionUser());
				entityManager.persist(object);
			}
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage(), e);
			entityManager.getTransaction().rollback();
			throw e;
		} finally {
			if (entityManager != null)
				entityManager.close();
		}
	}

	protected static <T> T update(final T object) {
		EntityManager entityManager = null;
		T mergedObject = null;
		try {
			entityManager = JPAUtils.getEntityManager();
			entityManager.getTransaction().begin();
			((BaseModel) object).setModifiedBy(getSessionUser());
			mergedObject = entityManager.merge(object);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage(), e);
			entityManager.getTransaction().rollback();
			throw e;
		} finally {
			if (entityManager != null)
				entityManager.close();
		}
		return mergedObject;
	}

	protected static <T> void delete(final Integer id, final Class<T> type) {
		EntityManager entityManager = null;
		try {
			entityManager = JPAUtils.getEntityManager();
			entityManager.getTransaction().begin();
			T object = (T) entityManager.find(type, id);
			entityManager.remove(object);
			entityManager.getTransaction().commit();
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage(), e);
			entityManager.getTransaction().rollback();
			throw e;
		} finally {
			if (entityManager != null)
				entityManager.close();
		}
	}
}