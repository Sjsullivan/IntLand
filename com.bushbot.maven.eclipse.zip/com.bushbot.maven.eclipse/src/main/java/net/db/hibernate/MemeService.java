/**
 * 
 */
package net.db.hibernate;

import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;

import net.db.hibernate.MemeDaoImpl;
import net.db.hibernate.MemeDao;
import net.db.hibernate.Meme;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2023-05-14
 *
 */
public class MemeService {
	private static final Logger sLogger = Logger.getLogger(MemeService.class.getName());
	
	/**
	 * Register Meme to system. Can be used for local authentication with supplied password
	 * @param Meme Meme to be registered in the system. Should also have required MemeProfile information
	 * @param password Password to register Meme with. Local authentication requires non-blank password
	 * @return Meme Id for registered Meme
	 * @throws BusinessException
	 */
	public static Integer registerMeme(Integer userId, Integer memeListId) throws BusinessException {

		Meme Meme = new Meme();
		try {
			MemeDao MemeDao = new MemeDaoImpl();
			Meme.setUserId(userId);
			Meme.setMemeListId(memeListId);
			Meme.setLevel(1);
			MemeDao.insertMeme(Meme);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error registering Meme.");
		}
		
		return Meme.getId();
	}
	
	/**
	 * Retrieve currently logged in Meme
	 * @return Meme currently logged in
	 * @throws BusinessException When there is an error retrieving the Meme, message should be safe to show Meme
	 */
	public static void updateMeme(Meme Meme) throws BusinessException {	
		try {
		MemeDao MemeDao = new MemeDaoImpl();
		MemeDao.updateMeme(Meme);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating Meme.");
		}
	}
	
	/**
	 * Retrieve Meme by Meme Id in system
	 * @param id Auto generated Id of the Meme in the system
	 * @return Meme with supplied id
	 * @throws BusinessException When there is an error retrieving the Meme, message should be safe to show Meme
	 */
	public static Meme getMemeById(Integer id) throws BusinessException {
		if (id == null || id <= 0) {
			throw new BusinessException("Invalid Meme ID");
		}
		
		try {
			MemeDao MemeDao = new MemeDaoImpl();
			return MemeDao.getMemeById(id);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid Meme ID");
		}
	}
	
	/**
	 * Retrieve Meme by supplied name address
	 * @param name Memes unique name in the system 
	 * @return Meme with supplied name
	 * @throws BusinessException When there is an error retrieving the Meme, message should be safe to show Meme
	 */
	public static Meme getMemeByName(String name) throws BusinessException {
		if (StringUtils.isBlank(name)) {
			throw new BusinessException("Name is blank");
		}
		
		try {
			MemeDao MemeDao = new MemeDaoImpl();
			return MemeDao.getMemeByName(name);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid email");
		}
	}
	
	/**
	 * Retrieve Memes by supplied userId
	 * @param userId Memes' userId in the system 
	 * @return Meme List from supplied userId
	 * @throws BusinessException When there is an error retrieving the Meme, message should be safe to show Meme
	 */
	public static List<Meme> getMemesByUserId(Integer userId) throws BusinessException {
		List<Meme> MemeList = null;
		try {
			MemeDao MemeDao = new MemeDaoImpl();
			MemeList = MemeDao.getMemesByUserId(userId);
			return MemeList;
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			return MemeList;
		}
	}
}
