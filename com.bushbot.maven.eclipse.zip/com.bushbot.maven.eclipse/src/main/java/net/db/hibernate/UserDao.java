/**
 * 
 */
package net.db.hibernate;

import java.util.List;

import net.db.hibernate.User;

/**
 * User access object for interaction with the database
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-08
 *
 */
public interface UserDao {

	/**
	 * Insert new user into database, passed in user object will be updated with new
	 * generated id upon success
	 * @param user System user to be inserted into database with non-null UserProfile
	 *             pre-populated
	 * @throws Exception If there was an issue inserting object and there was also a
	 *                   problem during rollback transaction or Database connection
	 *                   is closed
	 */
	public void insertUser(User user) throws Exception;

	/**
	 * Retrieves a user with supplied username
	 * @param username Users' username
	 * @return User with supplied username
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public User getUserByUsername(String username) throws Exception;

	/**
	 * Retrieves a user with supplied user id
	 * @param id Users' auto-generated id in the system
	 * @return User with supplied email address
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public User getUserById(Integer id) throws Exception;
	
	/**
	 * Retrieves a user with supplied user discordId
	 * @param discordId Users' auto-generated id in the system
	 * @return User with supplied discordId
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public User getUserByDiscordId(String discordId) throws Exception;
	
	/**
	 * Retrieves a user with supplied user walletId
	 * @param walletId Users' auto-generated id in the system
	 * @return User with supplied walletId
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public User getUserByWalletId(Integer walletId) throws Exception;
	
	/**
	 * Retrieves a user with supplied user collectionId
	 * @param collectionId Users' auto-generated id in the system
	 * @return User with supplied collectionId
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public User getUserByCollectionId(Integer collectionId) throws Exception;
	
	/**
	 * Retrieves a user with supplied user flagsId
	 * @param flagsId Users' auto-generated id in the system
	 * @return User with supplied flagsId
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public User getUserByFlagsId(Integer flagsId) throws Exception;
	
	/**
	 * Retrieves all users with supplied role id
	 * @param id Role id for users
	 * @return Users with supplied role id
	 * @throws Exception If there was an issue retrieving objects or Database connection
	 *                   is closed
	 */
	public List<User> getUsersByRole(Integer id) throws Exception;

	/**
	 * Updates a user with new information
	 * @param user new object with new information
	 * @return Updated user
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public User updateUser(User user) throws Exception;

	/**
	 * Permanently removed a user from the system with provided id
	 * @param id User id of the user to remove
	 * @throws Exception If there was an issue removing object or Database connection
	 *                   is closed
	 */
	public void deleteUser(Integer id) throws Exception;


}
