/**
 * 
 */
package net.db.hibernate;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;

import net.db.hibernate.UserDaoImpl;
import net.db.hibernate.UserDao;
import net.db.hibernate.User;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-08
 *
 */
public class WalletService {
	private static final Logger sLogger = Logger.getLogger(UserService.class.getName());
	
	/**
	 * Register wallet to system. 
	 * @param wallet Wallet to be registered in the system.
	 * @return Wallet Id for registered wallet
	 * @throws BusinessException
	 */
	public static Integer registerWallet(int userId) throws BusinessException {

		Wallet wallet = new Wallet();
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setUserId(userId);
			walletDao.insertWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error registering wallet.");
		}
		
		return wallet.getId();
	}
	
	/**
	 * Updates provided wallet with added IntCoins
	 * @param amount Integer of IntCoins to be added
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void addIntCoins(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setIntCoins(wallet.getIntCoins()+amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with IntCoins.");
		}
	}
	
	/**
	 * Updates provided wallet with removed IntCoins
	 * @param amount Integer of IntCoins to be removed
	 * @param wallet Wallet to remove amount from
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void removeIntCoins(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setIntCoins(wallet.getIntCoins()-amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with IntCoins.");
		}
	}
	
	/**
	 * Updates provided wallet with added Glizzy Gold
	 * @param amount Integer of Glizzy Gold to be added
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void addGlizzyGold(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setGlizzyGold(wallet.getGlizzyGold()+amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Glizzy Gold.");
		}
	}
	
	/**
	 * Updates provided wallet with removed GlizzyGold
	 * @param amount Integer of GlizzyGold to be removed
	 * @param wallet Wallet to remove amount from
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void removeGlizzyGold(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setGlizzyGold(wallet.getGlizzyGold()-amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Glizzy Gold.");
		}
	}
	
	/**
	 * Updates provided wallet with added DarkDiamonds
	 * @param amount Integer of DarkDiamonds to be added
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void addDarkDiamonds(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setDarkDiamonds(wallet.getDarkDiamonds()+amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with DarkDiamonds.");
		}
	}
	
	/**
	 * Updates provided wallet with added MudPieces
	 * @param amount Integer of MudPieces to be added
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void addMudPieces(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setMudPieces(wallet.getMudPieces()+amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Mud Pieces.");
		}
	}
	
	/**
	 * Updates provided wallet with removed MudPieces
	 * @param amount Integer of MudPieces to be removed
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void removeMudPieces(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setMudPieces(wallet.getMudPieces()-amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Mud Pieces.");
		}
	}
	
	/**
	 * Updates provided wallet with added MemeDust
	 * @param amount Integer of MemeDust to be added
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void addMemeDust(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setMemeDust(wallet.getMemeDust()+amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Mud Pieces.");
		}
	}
	
	/**
	 * Updates provided wallet with removed MemeDust
	 * @param amount Integer of MemeDust to be removed
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void removeMemeDust(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setMemeDust(wallet.getMemeDust()-amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Mud Pieces.");
		}
	}
	
	/**
	 * Updates provided wallet with added WeaponCores
	 * @param amount Integer of WeaponCores to be added
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void addWeaponCores(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setWeaponCores(wallet.getWeaponCores()+amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Mud Pieces.");
		}
	}
	
	/**
	 * Updates provided wallet with removed WeaponCores
	 * @param amount Integer of WeaponCores to be removed
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void removeWeaponCores(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setWeaponCores(wallet.getWeaponCores()-amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Mud Pieces.");
		}
	}
	
	/**
	 * Updates provided wallet with added ArmorCores
	 * @param amount Integer of ArmorCores to be added
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void addArmorCores(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setArmorCores(wallet.getArmorCores()+amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Mud Pieces.");
		}
	}
	
	/**
	 * Updates provided wallet with removed ArmorCores
	 * @param amount Integer of ArmorCores to be removed
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void removeArmorCores(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setArmorCores(wallet.getArmorCores()-amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Mud Pieces.");
		}
	}
	
	/**
	 * Updates provided wallet with added MudArtifacts
	 * @param amount Integer of MudArtifacts to be added
	 * @param wallet Wallet to add amount to
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static void addMudArtifacts(Integer amount, Wallet wallet) throws BusinessException {	
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet.setMudArtifacts(wallet.getMudArtifacts()+amount);
			walletDao.updateWallet(wallet);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating wallet with Mud Artifacts.");
		}
	}
	
	/**
	 * Retrieve currently logged in wallet
	 * @return Wallet currently logged in
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static Wallet getCurrentWallet() throws BusinessException {	
		return getWalletById((int) SecurityUtils.getSubject().getPrincipal());
	}
	
	/**
	 * Retrieve Wallet by wallet Id in system
	 * @param id Auto generated Id of the wallet in the system
	 * @return Wallet with supplied id
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static Wallet getWalletById(Integer id) throws BusinessException {
		if (id == null || id <= 0) {
			throw new BusinessException("Invalid Wallet ID");
		}
		
		try {
			WalletDao walletDao = new WalletDaoImpl();
			return walletDao.getWalletById(id);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid Wallet ID");
		}
	}
	
	/**
	 * Retrieve wallet by supplied discordId address
	 * @param discordId Wallets unique discordId in the system 
	 * @return Wallet with supplied discordId
	 * @throws BusinessException When there is an error retrieving the wallet, message should be safe to show wallet
	 */
	public static Wallet getWalletByUserId(Integer userId) throws BusinessException {
		Wallet wallet = null;
		try {
			WalletDao walletDao = new WalletDaoImpl();
			wallet = walletDao.getWalletByUserId(userId);
			return wallet;
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			return wallet;
		}
	}
}
