package net.db.hibernate;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import net.db.hibernate.BaseDao;
import net.db.hibernate.FlagsDao;
import net.db.hibernate.Flags;

/**
 * Implementation of Wallet access object for interaction with the database
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-08
 *
 */
public class FlagsDaoImpl extends BaseDao implements FlagsDao {

	@Override
	public void insertFlags(Flags flags) throws Exception
	{
		flags.setCreatedBy("BushBot");
		flags.setModifiedBy("BushBot");
		insert(flags);
	}

	@Override
	public Flags getFlagsById(Integer id) throws Exception
	{
		Flags flags = null;
		flags = getSingle(id, Flags.class);
		return flags;
	}
	
	@Override
	public Flags getFlagsByUserId(Integer userId) throws Exception
	{
		final Map<String, Object> parameterMap = new ConcurrentHashMap<>();
		parameterMap.put("userId", userId);
		return getSingle("SELECT f FROM Flags f WHERE userId=:userId", parameterMap, Flags.class);
	}

	@Override
	public Flags updateFlags(Flags flags) throws Exception
	{
		return update(flags);
	}

	@Override
	public void deleteFlags(Integer id) throws Exception
	{
		delete(id, Flags.class);
	}

	
}
