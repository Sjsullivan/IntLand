/**
 * 
 */
package net.db.hibernate;

import java.util.List;

import net.db.hibernate.User;

/**
 * Flags access object for interaction with the database
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-08
 *
 */
public interface FlagsDao {

	/**
	 * Insert new flags into database, passed in flags object will be updated with new
	 * generated id upon success
	 * @param flags System flags to be inserted into database with default values
	 *             pre-populated
	 * @throws Exception If there was an issue inserting object and there was also a
	 *                   problem during rollback transaction or Database connection
	 *                   is closed
	 */
	public void insertFlags(Flags flags) throws Exception;

	/**
	 * Retrieves a flags with supplied flags id
	 * @param id Flags's auto-generated id in the system
	 * @return Flags with supplied id
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Flags getFlagsById(Integer id) throws Exception;
	
	/**
	 * Retrieves a flags with supplied user id
	 * @param userId User id of flags in the system
	 * @return Flags with supplied userId
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Flags getFlagsByUserId(Integer id) throws Exception;

	/**
	 * Updates a flags with new information
	 * @param flags new object with new information
	 * @return Updated flags
	 * @throws Exception If there was an issue retrieving object or Database connection
	 *                   is closed
	 */
	public Flags updateFlags(Flags flags) throws Exception;

	/**
	 * Permanently remove a flags from the system with provided id
	 * @param id Flags id of the flags to remove
	 * @throws Exception If there was an issue removing object or Database connection
	 *                   is closed
	 */
	public void deleteFlags(Integer id) throws Exception;


}
