/**
 * 
 */
package net.db.hibernate;

import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.SecurityUtils;

import net.db.hibernate.UserDaoImpl;
import net.db.hibernate.UserDao;
import net.db.hibernate.User;

/**
 *
 *
 * @author Shane Sullivan
 * @version 1.0
 * @since 2022-03-08
 *
 */
public class UserService {
	private static final Logger sLogger = Logger.getLogger(UserService.class.getName());
	
	/**
	 * Register user to system. Can be used for local authentication with supplied password
	 * @param user User to be registered in the system. Should also have required UserProfile information
	 * @param password Password to register user with. Local authentication requires non-blank password
	 * @return User Id for registered user
	 * @throws BusinessException
	 */
	public static Integer registerUser(String discordId, String username) throws BusinessException {

		User user = new User();
		try {
			UserDao userDao = new UserDaoImpl();
			user.setDiscordId(discordId);
			user.setUsername(username);
			userDao.insertUser(user);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error registering user.");
		}
		
		return user.getId();
	}
	
	/**
	 * Retrieve currently logged in user
	 * @return User currently logged in
	 * @throws BusinessException When there is an error retrieving the user, message should be safe to show user
	 */
	public static void updateUser(User user) throws BusinessException {	
		try {
		UserDao userDao = new UserDaoImpl();
		userDao.updateUser(user);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Error updating user.");
		}
	}
	
	/**
	 * Retrieve currently logged in user
	 * @return User currently logged in
	 * @throws BusinessException When there is an error retrieving the user, message should be safe to show user
	 */
	public static User getCurrentUser() throws BusinessException {	
		return getUserById((int) SecurityUtils.getSubject().getPrincipal());
	}
	
	/**
	 * Retrieve User by user Id in system
	 * @param id Auto generated Id of the user in the system
	 * @return User with supplied id
	 * @throws BusinessException When there is an error retrieving the user, message should be safe to show user
	 */
	public static User getUserById(Integer id) throws BusinessException {
		if (id == null || id <= 0) {
			throw new BusinessException("Invalid User ID");
		}
		
		try {
			UserDao userDao = new UserDaoImpl();
			return userDao.getUserById(id);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid User ID");
		}
	}
	
	/**
	 * Retrieve user by supplied username address
	 * @param username Users unique username in the system 
	 * @return User with supplied username
	 * @throws BusinessException When there is an error retrieving the user, message should be safe to show user
	 */
	public static User getUserByUsername(String username) throws BusinessException {
		if (StringUtils.isBlank(username)) {
			throw new BusinessException("Discord ID is blank");
		}
		
		try {
			UserDao userDao = new UserDaoImpl();
			return userDao.getUserByUsername(username);
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			throw new BusinessException("Invalid email");
		}
	}
	
	/**
	 * Retrieve user by supplied discordId address
	 * @param discordId Users unique discordId in the system 
	 * @return User with supplied discordId
	 * @throws BusinessException When there is an error retrieving the user, message should be safe to show user
	 */
	public static User getUserByDiscordId(String discordId) throws BusinessException {
		if (StringUtils.isBlank(discordId)) {
			throw new BusinessException("Discord ID is blank");
		}
		User user = null;
		try {
			UserDao userDao = new UserDaoImpl();
			user = userDao.getUserByDiscordId(discordId);
			return user;
		} catch (Exception e) {
			sLogger.log(Level.WARNING, e.getMessage());
			return user;
		}
	}
}
